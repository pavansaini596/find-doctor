<?php
ob_start();

 include("header.php");
 $det=$_REQUEST["id"];
                     
	  $c=mysqli_connect("localhost","root","","doctor");
			if($c==false)
			{
				die ("error in connection");
			}
			  
			$query=mysqli_query($c,"select * from doctorinfo where id= $det");
		
			$count=mysqli_num_rows($query);
			if($count>=1)
			{
				  
				  while($r=mysqli_fetch_row($query))
				  {
                    echo' <div class="single-page main-grid-border">
						<div class="container">
							<div class="product-desc">
								<div class="col-md-7 product-view">
									<h2>'.$r[1].'</h2>
									<p> <i class="glyphicon glyphicon-map-marker"></i>'.$r[6].', '.$r[7].', '.$r[8].', '.$r[9].' | Specialization :- '.$r[5].' | Qualification :- '.$r[13].'</p>
									<div class="flexslider">
										<ul class="slides">
											<li >
												<img src="web/images/'.$r[11].'" "width=50%vw height=50%vw"/>
											</li>
											
										</ul>
									</div>
									
									<div class="product-details">
										<h4><span class="w3layouts-agileinfo">Hospital / Clinic Name </span> :&nbsp;'.$r[4].'<div class="clearfix"></div></h4>
										<h4><span class="w3layouts-agileinfo">specialization </span> :&nbsp;'.$r[5].'<div class="clearfix"></div></h4>
										<h4><span class="w3layouts-agileinfo">Qualification </span> :&nbsp;'.$r[13].'<div class="clearfix"></div></h4>';
										
										$c=mysqli_connect("localhost","root","","doctor");
											if($c==false)
											{
												die ("error in connection");
											}
											  
											$query=mysqli_query($c,"select * from experience where doctor_id= $det");
										
											$count=mysqli_num_rows($query);
											if($count>=1)
											{
												  
												  while($j=mysqli_fetch_row($query))
												  {
													echo'
														<div class="product-price">
															<p class="p-price"> Hospital Name :- '.$j[2].'</p>
															<h3 class="rate"> Experience (in year) :- '.$j[3].'</h3>
														
															<h3 class="rate"> field :- '.$j[6].'</h3>
															
															<div class="clearfix"></div>
														</div>';
												   }
											}
											
									echo'	<!--<h4><span class="w3layouts-agileinfo">Views </span> : <strong>150</strong></h4>
										<h4><span class="w3layouts-agileinfo">Fuel </span> : Petrol</h4>
										<h4><span class="w3layouts-agileinfo">Summary</span> :<p>It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using , making it look like readable English.</p><div class="clearfix"></div></h4>-->
									
									</div>
								</div>
								<div class="col-md-5 product-details-grid">
								<div class="item-price">
								<!--<table>
								   <tr>
								       <td> hospital name</td>
									   <td> Metting time</td>
									   <td> Day</td>
									   <td> Fee</td>
								   </tr>-->';
							$c=mysqli_connect("localhost","root","","doctor");
							if($c==false)
							{
								die ("error in connection");
							}
							  
							$query=mysqli_query($c,"select * from metting where doctor_id= $det");
						
							$count=mysqli_num_rows($query);
							if($count>=1)
							{
								  
								  while($e=mysqli_fetch_row($query))
								  {
									echo'
										<div class="product-price">
											<p class="p-price"> Hospital Name :- '.$e[2].'</p>
											<h3 class="rate"> Metting Time :- '.$e[3].'</h3>
											<h3 class="rate"> Metting Day :- '.$e[4].'</h3>
											<h3 class="rate"> Fees (RS):- '.$e[5].'</h3>
											
											<div class="clearfix"></div>
										</div>';
								   }
							}
					     	// <div class="condition">
											// <p class="p-price">Condition</p>
											// <h4>Good</h4>
											// <div class="clearfix"></div>
										// </div>
										// <div class="itemtype">
											// <p class="p-price">Item Type</p>
											// <h4>Cars</h4>
											// <div class="clearfix"></div>
										// </div>
								echo'	</div>
									<div class="interested text-center">
										<h4>Interested in Appointment<small> </small></h4>
										<form action="" method="post">
										 <button type="submit" class="btn btn-success " name="appoint">Appointment</button>
										 </form>
										 ';
										
										     
											 if(isset($_POST["appoint"]))
											 {
												 session_start();
												 if(!empty($_SESSION["udemo"]))
												 {
													 header("location:web/uappointment.php?id=$det");
												 }
												 else
												 {
													 echo" please login ";
												 }
	                                         
											 }
											 
										
										echo'</div>	
						
								<!-- <div class="tips">
										<h4>Safety Tips for Buyers</h4>
											<ol>
												<li><a href="#">Contrary to popular belief.</a></li>
												<li><a href="#">Contrary to popular belief.</a></li>
												<li><a href="#">Contrary to popular belief.</a></li>
												<li><a href="#">Contrary to popular belief.</a></li>
												<li><a href="#">Contrary to popular belief.</a></li>
												<li><a href="#">Contrary to popular belief.</a></li>
												<li><a href="#">Contrary to popular belief.</a></li>
												<li><a href="#">Contrary to popular belief.</a></li>
												<li><a href="#">Contrary to popular belief.</a></li>
											</ol>
										</div>-->
								</div>
							<div class="clearfix"></div>
							</div>
						</div>
					</div>';
				  }
			}
 include("footer.php");
 ob_end_flush();
?>	
<?php
        include("header.php");
        if(isset($_POST["check"]))
        {
        	$loc=$_POST["loca"];
        	$detail=$_POST["det"];
        	
?>


<div class="agileinfo-ads-display col-md-9">
					<div class="wrapper">					
					<div class="bs-example bs-example-tabs" role="tabpanel" data-example-id="togglable-tabs">
					 <ul id="myTab" class="nav nav-tabs nav-tabs-responsive" role="tablist">
						<li role="presentation" class="active">
						  <a href="#home" id="home-tab" role="tab" data-toggle="tab" aria-controls="home" aria-expanded="true">
							<span class="text">View Doctors</span>
						  </a>
						</li></ul>
						<!-- <li role="presentation" class="next">
						  <a href="#profile" role="tab" id="profile-tab" data-toggle="tab" aria-controls="profile">
							<span class="text">Ads with Photos</span>
						  </a>
						</li>
						<li role="presentation">
						  <a href="#samsa" role="tab" id="samsa-tab" data-toggle="tab" aria-controls="samsa">
							<span class="text">Company</span>
						  </a>
						</li>
					  </ul>-->
					  <div id="myTabContent" class="tab-content">
						<div role="tabpanel" class="tab-pane fade in active" id="home" aria-labelledby="home-tab">
						   <div>
												<div id="container">
								
								<!-- <div class="sort">
								   <div class="sort-by">
										<label>Sort By : </label>
										<select>
														<option value="">Most recent</option>
														<option value="">Price: Rs Low to High</option>
														<option value="">Price: Rs High to Low</option>
										</select>
									   </div>
									 </div> -->
								<div class="clearfix"></div>
							<ul class="list">
								<?php
							  $c=mysqli_connect("localhost","root","","doctor");
							if($c==false)
							{
								die ("error in connection");
							}
                             
                              
							$query=mysqli_query($c,"SELECT * from doctorinfo join department on doctorinfo.dept_id=department.id where (address like '$loc%' or landmark like '$loc%' or c_v_name like '$loc%' or state_name like '$loc%') and (specialization like '$detail%' or department_name ='$detail')");
						
							$count=mysqli_num_rows($query);
							if($count>=1)
							{
								  
								  while($r=mysqli_fetch_row($query))
								  {
									 
                                     echo"<a href='details.php?id=".$r[0]."'>
									<li>
									<img src='web/images/$r[11]' title='' alt='' 'width='150px' height='150px' />
									<section class='list-left'>
									<h5 class='title'>$r[1]</h5>
									<span class='adprice'>Hospital / Clinic Name :- $r[4]</span>
									<span class='adprice'>Specialization :- ".$r[5]."</span>
									<span class='adprice'>Qualification :- ".$r[13]."</span>
									<p class='catpath'></p>
									</section>
									<section class='list-right'>
									<span class='date'></span>
									<span class='cityname'>Address :- $r[6], $r[7], $r[8], $r[9]</span>
									</section>
									<div class='clearfix'></div>
									</li> 
								</a>";
									 
								  } 
							}
                             else
							 {
								  echo" <div class='alert alert-danger '>
									 
									  <strong>Doctor Are Not Available This Department &nbsp; <a href='index.php' class='alert-link'> GO To Home</a> </strong>
									   </div>";
							 }								 
							
							?>
								
								
								
							</ul>
						</div>
							</div>
						</div>
						<div role="tabpanel" class="tab-pane fade" id="samsa" aria-labelledby="samsa-tab">
						  <div>
												<div id="container">
								<div class="view-controls-list" id="viewcontrols">
									<label>view :</label>
									<a class="gridview"><i class="glyphicon glyphicon-th"></i></a>
									<a class="listview active"><i class="glyphicon glyphicon-th-list"></i></a>
								</div>
								<div class="sort">
								   <div class="sort-by">
										<label>Sort By : </label>
										<select>
														<option value="">Most recent</option>
														<option value="">Price: Rs Low to High</option>
														<option value="">Price: Rs High to Low</option>
										</select>
									   </div>
									 </div>
								<div class="clearfix"></div>
							<ul class="list">
							
								
								
								
							</ul>
						</div>
							</div>
						</div>
						
					  </div>
					</div>
				</div>
				</div>
<?php
}
 include("footer.php");
?>		
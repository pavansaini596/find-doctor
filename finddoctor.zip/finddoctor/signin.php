<?php
ob_start();
?>
<html>
	<head>
		  <title>Doctor and Patient Signin</title>	
    		  <link rel="stylesheet" href="css/bootstrap.min.css"><!-- bootstrap-CSS -->
            <meta name="viewport" content="width=device-width, initial-scale=1">
			<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
			<meta name="keywords" content="" />
			<link rel="stylesheet" href="css/bootstrap-select.css"><!-- bootstrap-select-CSS -->
			<link href="css/style.css" rel="stylesheet" type="text/css" media="all" /><!-- style.css -->
			<link rel="stylesheet" href="css/font-awesome.min.css" />
			<link href='//fonts.googleapis.com/css?family=Ubuntu+Condensed' rel='stylesheet' type='text/css'>
			<link href='//fonts.googleapis.com/css?family=Open+Sans:400,300,300italic,400italic,600,600italic,700,700italic,800,800italic' rel='stylesheet' type='text/css'>
              <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
             <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
             <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
 <?php
		include("header.php");
	?>
	</head>
	<body>
	 
       <div id="agileits-sign-in-page" class="sign-in-wrapper">
			<div class="agileinfo_signin">
			<h3>Sign in</h3>
			<ul class="nav nav-tabs sigf">
						   <li class="col-sm-6 nav-item"><a class="nav-link" data-toggle="tab" href="#logdoc">Login As Doctor</a></li>
						   <li class="col-sm-6 nav-item"><a class="nav-link" data-toggle="tab" href="#logpes">Login As Patient</a></li>
						  </ul>
						  <div class="tab-content">
						  <div id="logdoc" class="tab-pane fade"><br>
						             <h3>Login As Doctor</h3>
									<form  action="" method="post" >
												<label> Email Or Mobile Number *</label>
												<input class="form-control" type="text" name="email" placeholder="Your Email Or Mobile Number" required> 
												<label>Password *</label>
												<input class="form-control" type="password" name="pwd" placeholder="Password" required=""> 
												<input class="form-control" type="submit" name="dlog" value="Sign In">
								   </form>
							</div>
							<?php
							
							if(isset($_POST["dlog"]))
							{
								      $email=$_POST["email"];
									   $pwd=$_POST["pwd"];
									   $c=mysqli_connect("localhost","root","","doctor");
									    if($c==false)
									    {
										   die("Database connection error");
									   }
									   $query=mysqli_query($c,"select * from doctorinfo where (email='$email' or BINARY mobile_number= BINARY '$email') and BINARY dpassword= BINARY '$pwd'");
									   $count=mysqli_num_rows($query);
									   if($count>=1)
									   {
											$r=mysqli_fetch_row($query);
											if($r[14]=="Active")
											{
												session_start();			
												$_SESSION["demo"]=$r[0];  
												header("location:web/dindex.php");
											}
											else
											{
												 echo"<br><div class='alert alert-danger'>
													  <strong> your account is temporarily deactivate. Please contact admin and support team.</strong>
													</div>";
												
											}
									   }
									   else
									   {
										    echo"<br><div class='alert alert-danger'>
													  <strong> please enter correct detail</strong>
													</div>";
										   
									   }
						   }
				          ?>
						   <div id="logpes" class="tab-pane fade"><br>
								<form  action="" method="post">
								            <h3>Login As Patient</h3>
												<label> Email Or Mobile Number *</label>
												<input class="form-control" type="text" name="email" placeholder="Your Email Or Mobile Number" required> 
												<label>Password *</label>
												<input class="form-control" type="password" name="pwd" placeholder="Password" required=""> 
												<input class="form-control" type="submit" name="plog" value="Sign In">
											</form>
						 </div>
						 
						  <?php
							
						   if(isset($_POST["plog"]))
						   {
							           $email=$_POST["email"];
									   $pwd=$_POST["pwd"];
									   $c=mysqli_connect("localhost","root","","doctor");
									    if($c==false)
									    {
										 die("Database connection error");
									   }
									   $query=mysqli_query($c,"select * from userinfo where (email='$email' or BINARY mobile_number= BINARY '$email') and BINARY upassword= BINARY '$pwd'");
									   $count=mysqli_num_rows($query);
									   if($count>=1)
									   {
											$r=mysqli_fetch_row($query);
											if($r[5]=="Active")
											{
												session_start();			
												$_SESSION["udemo"]=$r[0];  
												header("location:web/uindex.php");
											}
											else
											{
												 echo"<br><div class='alert alert-danger'>
													  <strong> your account is temporarily deactivate. Please contact admin and support team. </strong>
													</div>";
												
											}
									   }
									   else
									   {
										   echo"<br><div class='alert alert-danger'>
													  <strong> please enter correct detail</strong>
													</div>";
									   }
							  
						   }
				   ?>
					
					
				  </div>
				</div>
			  </div>
			  <?php
	    include("footer.php");
	?>
		</body>
</html>
<?php
ob_end_flush();
?>
<?php
	session_start();
	if(!empty($_SESSION["demo"]))
	{
			
			$uid=$_SESSION["demo"];
			$apid=$_REQUEST["id"];
			$c=mysqli_connect("localhost","root","","doctor");
	    	  if($c==false)
			   {
				  die("Database connection error");
			   }
			  if(mysqli_query($c,"update appointment set app_status='Confirm' where id='$apid'"))
			  {
				  header("location:dappointment.php");
				  
			  }
			  else
			  {
				  echo "appointment not confirm";
			  }
}
	else
	{
		header("location:../signin.php");
	}			  
?>
	  
    
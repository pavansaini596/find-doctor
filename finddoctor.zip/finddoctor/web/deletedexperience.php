<?php
 session_start();
	if(!empty($_SESSION["demo"]))
	{ 
     $eid=$_REQUEST["id"];
	 $c=mysqli_connect("localhost","root","","doctor");
	  if($c==false)
	   {
		  die("Database connection error");
	   }
	 if(mysqli_query($c,"delete from experience where id='$eid'"))
	 {
		  header("location:dexperience.php");
	 }
	}
	else
	{
		header("location:../signin.php");
	}
?>
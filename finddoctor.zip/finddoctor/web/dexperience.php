
<?php
   

    session_start();
	if(!empty($_SESSION["demo"]))
	{
		
?>
<!DOCTYPE html>
<html lang="en">

<head>

  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="">
  
  <title>Docter experience </title>
  <link href="css/bootstrap.min.css" rel="stylesheet">
  <link href="css/dataTables.bootstrap4.css" rel="stylesheet">
  <link href="css/sb-admin.css" rel="stylesheet">

</head>

<body id="page-top">

  <nav class="navbar navbar-expand navbar-dark bg-dark static-top">
    <a class="navbar-brand mr-1" href="dindex.php">Welcome Doctor</a>
  </nav>

  <div id="wrapper">
    <ul class="sidebar navbar-nav text-light">
	 <li class="nav-item ">
        <a class="nav-link" href="../index.php">
          <span>Web Home</span>
        </a>
      </li>
	  <li class="nav-item ">
        <a class="nav-link" href="dindex.php">
          <span>Dashbord</span>
        </a>
      </li>
      <li class="nav-item ">
        <a class="nav-link" href="dprofile.php">
          <span>Profile</span>
        </a>
      </li>
	   <li class="nav-item ">
        <a class="nav-link" href="dexperience.php">
          <span>Experience</span>
        </a>
      </li>
	   <li class="nav-item ">
        <a class="nav-link" href="dmetting.php">
          <span>Metting</span>
        </a>
      </li>
	   <li class="nav-item ">
        <a class="nav-link" href="dappointment.php">
          <span>Appointment</span>
        </a>
      </li>
	   <li class="nav-item ">
        <a class="nav-link" href="logout.php">
          <span>logout</span>
        </a>
      </li>
	   
      
    </ul>

    <div id="content-wrapper">

      <div class="container-fluid">
	  <div class="container text-center mt-2 mb-4 bg-success">
		          <h2>Experience</h2>
		   </div>
	   <div class="row">
	    <?php
			$uid=$_SESSION["demo"];
			$c=mysqli_connect("localhost","root","","doctor");
	    	  if($c==false)
			   {
				  die("Database connection error");
			   }
			     echo"
					<div class='col-sm-12 col-md-4 col-lg-4 mt-2'>
                        <form action='' method='post'>
                          <div class='form-group '>
							<label> Hospital Name</label>
						   <input class='form-control' type='text' name='hname' placeholder='Enter Hospital Name'required>
							 Experience (year) 
							 <input class='form-control' type='tel' name='exp' placeholder='Enter Experience Year' required>
							 From Date 
							 <input class='form-control' type='date' name='fdate' placeholder='Enter Start Date'required>
							 To Date 
							 <input class='form-control' type='date' name='tdate' placeholder='Enter To Date'>
							 Detail <br>
							 <textarea class='form-control'name='detail' rows='7' cols='30' placeholder='Enter your other detail'></textarea>
					</div>
							<button type='submit' class='btn btn-primary' name='update'>Add Experience</button>
							 </form>
					</div>	";
					if(isset($_POST["update"]))
				      { 
						$name=$_POST["hname"];
						$exp=$_POST["exp"];
						$fdate=$_POST["fdate"];
						$tdate=$_POST["tdate"];
						$detail=$_POST["detail"];
			
						 
							  
						   if(mysqli_query($c,"insert into experience (doctor_id,hospital_name,experience,frome_date,to_date,detail) values('$uid','$name','$exp','$fdate','$tdate','$detail')"))
						   {
							   header("location:dexperience.php");
						   }   
						   else
						   {
							   echo"Sorry your experience are not add Please retry";
						   }
					}
			  		 echo"<div class='col-sm-12 col-md-8 col-lg-8 mt-2'>
						<div class='table-responsive'>
						  <table class='table'>
							<tr>
							     <th>Hospital Name</th>
								 <th>Experience (year)</th>
								 <th>From Date</th>
								 <th>To Date</th>
								 <th>Detail</th>
								 <th>Edit</th>
								 <th>Delete</th>
						   </tr>";
						  	
                        $query=mysqli_query($c,"select * from experience where doctor_id='$uid'");
						 $count= mysqli_num_rows($query);
						 if($count>=1)
						 {
						   while($r=mysqli_fetch_row($query))
						   {   
							  echo"<tr>
							        <td>$r[2]</td>
									<td>$r[3]</td>
									<td>$r[4]</td>
									<td>$r[5]</td>
									<td>$r[6] </td>
									<td> 
									<a href='editdexperience.php?id=$r[0]'<button class='btn btn-primary' value=''>Edit</button></a>
									</td>
								     <td> 
									<a href='deletedexperience.php?id=$r[0]'<button class='btn btn-primary' value=''>Delete</button></a>
									</td>
									</tr>";
						   }
						 }

						echo"</table>
						</div>
                      </div>";				
	    ?>
	   </div>
	  
	  
	  
	  
	  
	     
        


      </div>
      
    </div>
    
  </div>
  
</body>

</html>
 

<?php
	}
	else
	{
		header("location:../signin.php");
	}
?>



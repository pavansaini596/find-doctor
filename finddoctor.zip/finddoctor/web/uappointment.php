<?php
   ob_start();

    session_start();
	
	if(!empty($_SESSION["udemo"]))
	{
		
		$uid=$_SESSION["udemo"];
		 if(!empty($_REQUEST["id"]))
				   {
		               $det=$_REQUEST["id"];
				   }
?>
<!DOCTYPE html>
<html lang="en">

<head>

  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="">
  
  <title></title>
  <link href="css/bootstrap.min.css" rel="stylesheet">
  <link href="css/dataTables.bootstrap4.css" rel="stylesheet">
  <link href="css/sb-admin.css" rel="stylesheet">
   <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>

</head>

<body id="page-top">

  <nav class="navbar navbar-expand navbar-dark bg-dark static-top">
    <a class="navbar-brand mr-1" href="uindex.php">Welcome Patient</a>
  </nav>

  <div id="wrapper">
    <ul class="sidebar navbar-nav text-light">
	 <li class="nav-item ">
        <a class="nav-link" href="../index.php">
          <span>Web Home</span>
        </a>
      </li>
	<li class="nav-item ">
        <a class="nav-link" href="uindex.php">
          <span>Dashboard</span>
        </a>
      </li>
      <li class="nav-item ">
        <a class="nav-link" href="uprofile.php">
          <span>Profile</span>
        </a>
      </li>
	   
	   <li class="nav-item ">
        <a class="nav-link" href="uappointment.php">
          <span>Appointment</span>
        </a>
      </li>
	   <li class="nav-item ">
        <a class="nav-link" href="logout.php">
          <span>logout</span>
        </a>
      </li>
	   
      
    </ul>

    <div id="content-wrapper">

      <div class="container-fluid">
	       <div class="container text-center mt-2 mb-2 bg-success">
		          <h2>Appointment</h2>
		   </div>
		      <form class="d-none d-md-inline-block form-inline ml-auto mr-0 mr-md-3 my-2 my-md-0">
      
	     <?php
			
			$c=mysqli_connect("localhost","root","","doctor");
	    	  if($c==false)
			   {
				  die("Database connection error");
			   }
			echo'  <div class="row mt-3">
			  <div class="container-fluid " style="font-size:30px;" >';
			  
				   $quer=mysqli_query($c,"select count(id) as total from appointment where patient_id='$uid'");
				      $co=mysqli_fetch_assoc($quer);
					  $qu=mysqli_query($c,"select count(id) as active from appointment where patient_id='$uid' and app_status='Pending'");
				      $cou=mysqli_fetch_assoc($qu);
					   $que=mysqli_query($c,"select count(id) as deactive from appointment where patient_id='$uid' and app_status='Cancel'");
				      $coun=mysqli_fetch_assoc($que);
					  $querc=mysqli_query($c,"select count(id) as conf from appointment where patient_id='$uid' and app_status='Confirm'");
				      $counc=mysqli_fetch_assoc($querc);
					   $querm=mysqli_query($c,"select count(id) as conm from appointment where patient_id='$uid' and app_status='Complete'");
				      $counm=mysqli_fetch_assoc($querm);
				  echo'<span class="badge badge-pill badge-info">Total&nbsp;'.$co["total"].'</span>
				   <span class="badge badge-pill badge-danger">Cancel &nbsp;'.$coun["deactive"].'</span>
				   <span class="badge badge-pill badge-warning">Pending &nbsp;'.$cou["active"].'</span>
				  <span class="badge badge-pill badge-success">Confirm &nbsp;'.$counc["conf"].'</span>
				  <span class="badge badge-pill badge-success">Complete &nbsp;'.$counm["conm"].'</span>
				  
               ';
          echo'   </div>
			</div>

			<ul class="nav nav-pills">
						<li><a data-toggle="tab" href="#vapp">Alredy Book Appoinment</a></li>
					  </ul>
					  <div class="tab-content">
						<div id="vapp" class="tab-pane fade">
						<div class="input-group mt-4">
						<input type="text" class="form-control" id="myInput" onkeyup="myFunction()"  placeholder="Rec. No. search" aria-label="Search" aria-describedby="basic-addon2">
							
						  </div>
						</form>
						   <div class="table-responsive-sm mt-5">          
			        <table id="myTable" class="table table-bordered  table-hover">
				
				  <thead class="pr-0 thead-dark">
				   <tr>
				   <th> Rec. No.:- </th>
				   <th> patient Name</th>
					<th>Hospital Name</th>
					<th>Appointment Time</th>
					<th>Appointment Day</th>
					<th>Appointment Date</th>
					<th>Fees</th>
	                <th>Status</th>
	                <th>View</th>
	                
			      </tr>
				</thead>';
			  $query=mysqli_query($c,"select * from appointment where patient_id= $uid order by id desc");				  
			 $count=mysqli_num_rows($query);
			  if($count>=1)
			    {
				  while($r=mysqli_fetch_row($query))
					  {
			           echo"
					          <tbody>
									   <tr>
									   <td>$r[0]</td>
									   <td>$r[9]</td>
									   <td>$r[3]</td>
										 <td>$r[4]</td>
										 <td>$r[5]</td>
										 <td>$r[6]</td>
										 <td>$r[7] </td>
										 <td>$r[8] </td>
										 <td>
										    <a href='pappointmentview.php?id=$r[0]'<button class='btn btn-primary' value=''>View</button></a>
										  </td>
										  
									   </tr>
									</tbody>
										  
									
									  
						 ";
					  }
			    }
				 echo"</table></div>
						</div>
					   
					  </div>";
			   
				   
				   if(!empty($_REQUEST["id"]))
				   {
					   echo'  <div class="table-responsive-sm mt-5">          
			        <table class="table table-bordered  table-hover">
				
				  <thead class="pr-0 thead-dark">
				   <tr>
					<th>Hospital Name</th>
					<th>Appointment Time</th>
					<th> AppointmentDay</th>
					<th> Appointment Fees</th>
					<th> Book Appointment</th>
			      </tr>
				</thead>';
				     $query=mysqli_query($c,"select * from metting where doctor_id=$det");				  
					 $count=mysqli_num_rows($query);
						  if($count>=1)
						  {
							  while($r=mysqli_fetch_row($query))
							  {
									
								 echo"<tbody>
									   <tr>
									   <td>$r[2]</td>
										 <td>$r[3]</td>
										 <td>$r[4]</td>
										 <td>$r[5]</td>
										 <td><a href='appointmentcreate.php?id=$r[0]'><button type='button' class='btn btn-primary' data-toggle='modal' data-target='#myModal'>Appointment Book</button></a>
										   
										 </td>
									   </tr>
									</tbody>
										  
									";
                            	 }
						      }
						  echo'</table>
						  </div>';
				   }	  
								
						  
				         
		?>
		 <script>
		function myFunction() {
		  var input, filter, table, tr, td, i, txtValue;
		  input = document.getElementById("myInput");
		  filter = input.value.toUpperCase();
		  table = document.getElementById("myTable");
		  tr = table.getElementsByTagName("tr");
		  for (i = 0; i < tr.length; i++) {
			td = tr[i].getElementsByTagName("td")[0];
			if (td) {
			  txtValue = td.textContent || td.innerText;
			  if (txtValue.toUpperCase().indexOf(filter) > -1) {
				tr[i].style.display = "";
			  } else {
				tr[i].style.display = "none";
			  }
			}       
		  }
		}
		
</script>		   
      </div>
      
    </div>
    
  </div>
  
</body>

</html>
 

<?php
	}
	else
	{
		header("location:../signin.php");
	}
	ob_end_flush();
?>
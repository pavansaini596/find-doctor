<?php
   

    session_start();
	if(!empty($_SESSION["demo"]))
	{
	  $apid=$_REQUEST["id"];
?>
<!DOCTYPE html>
<html lang="en">

<head>

  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="">
  
  <title>Docter metting </title>
  <link href="css/bootstrap.min.css" rel="stylesheet">
  <link href="css/dataTables.bootstrap4.css" rel="stylesheet">
  <link href="css/sb-admin.css" rel="stylesheet">

</head>

<body id="page-top">

  <nav class="navbar navbar-expand navbar-dark bg-dark static-top">
    <a class="navbar-brand mr-1" href="dindex.php">Welcome Doctor</a>
  </nav>

  <div id="wrapper">
    <ul class="sidebar navbar-nav text-light">
	<li class="nav-item ">
        <a class="nav-link" href="../index.php">
          <span>Home</span>
        </a>
      </li>
      <li class="nav-item ">
        <a class="nav-link" href="dprofile.php">
          <span>Profile</span>
        </a>
      </li>
	   <li class="nav-item ">
        <a class="nav-link" href="dexperience.php">
          <span>Experience</span>
        </a>
      </li>
	   <li class="nav-item ">
        <a class="nav-link" href="dmetting.php">
          <span>Metting</span>
        </a>
      </li>
	   <li class="nav-item ">
        <a class="nav-link" href="dappointment.php">
          <span>Appointment</span>
        </a>
      </li>
	   <li class="nav-item ">
        <a class="nav-link" href="logout.php">
          <span>logout</span>
        </a>
      </li>
	   
      
    </ul>

    <div id="content-wrapper">

      <div class="container-fluid">
	  <div class="container text-center mt-2 mb-4 bg-success">
		          <h2> View Appointment details</h2>
		   </div>
	    <?php
			$uid=$_SESSION["demo"];
			$c=mysqli_connect("localhost","root","","doctor");
	    	  if($c==false)
			   {
				  die("Database connection error");
			   }
			   echo'  <div class="table-responsive-sm mt-5 text-center">          
			        <table class="table table-bordered  table-hover">
				
				  <thead class="pr-0 thead-dark">
				   <tr>
				   <th colspan="3"> Appointment</th>
					</tr>
			      </thead>';
			  $query=mysqli_query($c,"select * from appointment where id= $apid");				  
			 $count=mysqli_num_rows($query);
			  if($count>=1)
			    {
				  $r=mysqli_fetch_row($query);
					  {
			           echo" <tbody>
					         <tr>
							   <td colspan='3'>$r[3]</td> 
							 </tr>
				             <tr>
				                 <td> Rec. No. : &nbsp;&nbsp; $r[0] </td>
								 <td> Appointment Time : &nbsp;&nbsp; $r[4]</td>
					             <td>Appointment Day : &nbsp;&nbsp; $r[5]</td>
			                 </tr> 
							  <tr>
							   <td>Appointment Date : &nbsp;&nbsp; $r[6]</td>
							    <td>Fees : &nbsp;&nbsp; $r[7]</td>
								<td>Status : &nbsp;&nbsp; $r[8]</td>
							  </tr>
							  <tr>
							   <td>Patient Name : &nbsp;&nbsp; $r[9]</td>
							    <td>Father/Husband Name : &nbsp;&nbsp; $r[10]</td>
								<td> Age : &nbsp;&nbsp; $r[11]</td>
							  </tr>
							  <tr>
							     <td colspan='3' class='font-weight-bold'>Detials</td>
							  </tr>";
							   $st=$r[8];
								
								 if($st!=="Cancel" && $st!=="Pending")
								 {
								   echo" <tr><td colspan='3'>
								   <form action='' method='post'>
								   <div class='form-group'>
									<textarea  class='form-control bg-warning'  name='description'  rows='10' cols='30' required>
									  $r[12]
									</textarea>
									<div></td>
									</tr>
									  <tr>
										<td>";
										$query=mysqli_query($c,"select * from doctorinfo where id= $uid");
										 $count=mysqli_num_rows($query);
										  if($count>=1)
											{
											  $d=mysqli_fetch_row($query);
												  {
													echo" <input type='hidden' class='form-control' name='dname' value='$d[1]'> ";
												  }
											}
										echo"</td>
									  </tr>
									<tr><td colspan='3'>
									<button type='submit' class='btn btn-primary' name='sub'>Submit</button>";
								 }
								 else
								 {
									 echo "Status  &nbsp;".$st;
								 }
								 echo"</form></td>
							   </tr>
							   
							  </tbody>
						 ";
						if(isset($_POST["sub"]))
						{
							$des=$_POST["description"];
							$dname=$_POST["dname"];
							if(mysqli_query($c,"update appointment set description='$des',doc_name='$dname' where id= $apid "))
							  {
								 $q=mysqli_query($c,"select * from appointment where id='$apid'");
									   $count=mysqli_num_rows($q);
								       if($count>=1)
									   { 
								          $r=mysqli_fetch_row($q);
										  mysqli_query($c,"update appointment set app_status='Complete' where id= $apid ");
										  {
											   header("location:dappointment.php");
										  }
									   }
									
							  }
							 else
							 {
								 echo"not update";
							 }
						}
					  }
					  
					  
			    }
				 echo"</table></div>";
				  
	    ?>
	  
      </div>
    </div>
    
  </div>
  
</body>

</html>
 

<?php
	}
	else
	{
		header("location:../signin.php");
	}
?>
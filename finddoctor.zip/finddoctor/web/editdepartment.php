<?php
   session_start();
   if(!empty($_SESSION["sdemo"]))
   {
	  $edd=$_REQUEST["id"];
	  $c=mysqli_connect("localhost","root","","doctor");
		if($c==false)
		{
		   die("Database connection error");
	   }
	  
 ?>
 
 <!DOCTYPE html>
<html lang="en">

 <head>
  
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="">
  
  <title>Edit Department Details</title>
  <link href="css/bootstrap.min.css" rel="stylesheet">
  <link href="css/dataTables.bootstrap4.css" rel="stylesheet">
  <link href="css/sb-admin.css" rel="stylesheet">
  <?php
     include("sheader.php");
	 
   ?>
</head>
   
    <div id="content-wrapper">

         <div class="container-fluid   mb-5">
	        <div class="row">
			  
				   <div class=" container col-lg-4 col-md-6 col-sm-6 mt-lg-0 mt-3 bg-primary display-5 text-center p-2 text-light font-weight-bold">
				         <?php
						      
						       
						     $query=mysqli_query($c,"select * from department where id=$edd");
							  $count=mysqli_num_rows($query);
							  if($count>=1)
							  {
								   $r=mysqli_fetch_row($query);
						
						          echo" <form action='' method='post' enctype='multipart/form-data'>
							       <br><div class='form-group'>
								    <label>Department Name</label>
								    <input type='text' class='form-control' name='dept' value='$r[1]'>
							      </div>
							       <div class='form-group'>
								   <label>image</label>
								   <img src='deptimage/$r[2]'width='150' height='150'>
								   </div>
								   <div class='form-group'>
								   <label>New image</label>
								   <input type='file' class='form-control' name='pic'>
								   
							      </div>
							      <button type='submit' class='btn btn-warning text-center p-2 text-light font-weight-bold' name='update'>Update</button>
							  							  
						         </form>";
					          }
							  if(isset($_POST["update"]))
							    {
									 $name=$_POST["dept"];
										 										 
									   if(empty($_FILES['pic']['name']))
									   {
										   echo"empty file";
									   }
									   else{
											$ftype=$_FILES['pic']['type'];
											if($ftype=="image/png" || $ftype=="image/jpeg" || $ftype=="image/jpg")
											{
												$f=$_FILES['pic']['name'];
												$tf=$_FILES['pic']['tmp_name'];
												$t="deptimage/".$f;
												if(move_uploaded_file($tf,$t))
												{
												  if(mysqli_query($c,"update department set department_name='$name',department_img='$f' where id=$edd"))
													 {                   
														header("location:editdepartment.php?id=$edd");
													 }
													else
													 {
														 
														echo" <div class='alert alert-danger alert-dismissible'>
													      <button type='button' class='close' data-dismiss='alert'>&times;</button>
													      <strong>Your Photo is not upload....</strong>
													     </div>";
													 } 	
													 
												}
												else
												{    
											        echo" <div class='alert alert-danger alert-dismissible'>
													      <button type='button' class='close' data-dismiss='alert'>&times;</button>
													      <strong>Error in file uploading....</strong>
													     </div>";
													
												}
												
											}
											else
											{
												echo" <div class='alert alert-danger alert-dismissible'>
													  <button type='button' class='close' data-dismiss='alert'>&times;</button>
													  <strong>File is not in correct format! Please retry and select jpg, png and jpeg file</strong>
													   </div>";
											}
												
											
									   }
									 
							 }
					     ?>
					 </div>
					 
			  </div>
			 </div>
			 
			</div>

			  
			

       </div>
	 
	</div>
  
 <?php
  }

   else
   {
      header("location:../signin.php");
   }

?>
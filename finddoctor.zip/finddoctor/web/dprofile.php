
<?php
   ob_start();

    session_start();
	if(!empty($_SESSION["demo"]))
	{
		
?>
<!DOCTYPE html>
<html lang="en">

<head>

  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="">
  
  <title>Docter profile</title>
  <link href="css/bootstrap.min.css" rel="stylesheet">
  <link href="css/dataTables.bootstrap4.css" rel="stylesheet">
  <link href="css/sb-admin.css" rel="stylesheet">

</head>

<body id="page-top">

  <nav class="navbar navbar-expand navbar-dark bg-dark static-top">
    <a class="navbar-brand mr-1" href="dindex.php">Welcome Doctor</a>
  </nav>

  <div id="wrapper">
    <ul class="sidebar navbar-nav text-light">
	   <li class="nav-item ">
        <a class="nav-link" href="../index.php">
          <span>Web Home</span>
        </a>
      </li>
	  <li class="nav-item ">
        <a class="nav-link" href="dindex.php">
          <span>Dashbord</span>
        </a>
      </li>
      <li class="nav-item ">
        <a class="nav-link" href="dprofile.php">
          <span>Profile</span>
        </a>
      </li>
	   <li class="nav-item ">
        <a class="nav-link" href="dexperience.php">
          <span>Experience</span>
        </a>
      </li>
	   <li class="nav-item ">
        <a class="nav-link" href="dmetting.php">
          <span>Metting</span>
        </a>
      </li>
	   <li class="nav-item ">
        <a class="nav-link" href="dappointment.php">
          <span>Appointment</span>
        </a>
      </li>
	   <li class="nav-item ">
        <a class="nav-link" href="logout.php">
          <span>logout</span>
        </a>
      </li>
	   
      
    </ul>

    <div id="content-wrapper">

      <div class="container-fluid">
	       <div class="container text-center mt-2 mb-2 bg-success">
		          <h2>Profile</h2>
		   </div>
	     <?php
			$uid=$_SESSION["demo"];
			$c=mysqli_connect("localhost","root","","doctor");
	    	  if($c==false)
			   {
				  die("Database connection error");
			   }
			  $query=mysqli_query($c,"select * from doctorinfo where id='$uid'");
			  $count=mysqli_num_rows($query);
			  if($count>=1)
			  {
				   $r=mysqli_fetch_row($query);
				    echo"
					<div class='col-sm-12 col-md-6 col-lg-6 mt-2'>
                        <form action='' method='post' enctype='multipart/form-data'>
						            <div class='form-group '>
								        <label class='text-center'>Image</label> 
										<image src='images/$r[11]'width='150px' height='150px'><br><br>
										<input type='file'name='pic'><br><br>
								         
								  
								        <label> Name</label> 
										<input type='text' class='form-control' name='name' value='$r[1]' required>
								         <label> Email</label> 
										<input type='email' class='form-control' name='email' value='$r[2]' required>
								  
								        <label> Mobile Number</label> 
										<input type='tel'class='form-control' name='mob' value='$r[3]' pattern='[0-9]{10}' maxlength='10' minlength='10' size='10' required>
								     
									   <label> Hospital / Clinic Name</label> 
									  <input type='text' class='form-control' name='hcname' value='$r[4]'>
		     	                         <label>Already Selected Department </label>";
										 
									        $ddata=$r[12];
										    $c=mysqli_connect("localhost","root","","doctor");
											if($c==false)
											{
												die("data base conncection error ");
											}
											if($query=mysqli_query($c,"select * from department where id =$ddata"))
											{
												$count=mysqli_num_rows($query);
												  if($count>=1)
												  {
													  $r=mysqli_fetch_row($query);
													  {
														  echo "<input type=text class='form-control'value='$r[1]' disabled>";
													  }
												  }
											}
												  else
												  {
													 echo" <input type=text class='form-control'value='Not Select ' disabled>";
												  }
												  
									   echo"
								        <label> Department </label>
										<select class='form-control' name='dept' required >
										 <option value=''> Select Any Option </option>";
									      
										    $c=mysqli_connect("localhost","root","","doctor");
											if($c==false)
											{
												die("data base conncection error ");
											}
											$query=mysqli_query($c,"select * from department where d_status='Active'");
											$count=mysqli_num_rows($query);
											  if($count>=1)
											  {
												  while($r=mysqli_fetch_row($query))
												  {
													  echo "<option value='$r[0]'  > ".$r[1]." </option>";
												  }
											  }
											echo"</select>";

										
								
                           
                                $query=mysqli_query($c,"select * from doctorinfo where id='$uid'");
								  $count=mysqli_num_rows($query);
								  if($count>=1)
								  {
									   $r=mysqli_fetch_row($query);						   
									  echo"  <label> Specialization</label> 
									   <input type='text' class='form-control' name='spec' value=$r[5]>
								        <label>Qualification</label> 
									   <input type='text' class='form-control' name='qua' value=$r[13]>
									   <label> Address</label> 
									   <input type='text' class='form-control' name='addr' value='$r[6]'>
									   <label>Landmark</label> 
									   <input type='text' class='form-control' name='lmark' value='$r[7]'>
									   <label> City / Village</label> 
									   <input type='text' class='form-control' name='cvname' value='$r[8]'>
									   <label>State </label> 
									   <input type='text' class='form-control' name='state' value='$r[9]'>
									   <label> Password</label> 
									   <input type='text' class='form-control' name='pwd' value='$r[10]' required>
									   
								    </div>
									<button type='submit' class='btn btn-primary' name='update'>Update</button>
									
                              </form>   
							    
							   </form> <br>  
							   <form action='dstatus.php' method='get'>
							   <button type='submit' class='btn btn-danger' name='deactive'>Deactive Account</button>
                               </form>	
							   
					       </div>
						";				
			  }
			   if(isset($_POST["update"]))
		        {
						      $name=$_POST["name"];
							  $email=$_POST["email"];
							  $mob=$_POST["mob"];
							  $hcname=$_POST["hcname"];
							  $spec=$_POST["spec"];
							  $add=$_POST["addr"];
							  $lmark=$_POST["lmark"];
							  $civi=$_POST["cvname"];
							  $state=$_POST["state"];
							  $pwd=$_POST["pwd"];
							  $deptn=$_POST["dept"];
							   $qual=$_POST["qua"];
							  
						   if(empty($_FILES['pic']['name']))
						   {
							   echo"empty file";
						   }
						   else{
							    $ftype=$_FILES['pic']['type'];
								if($ftype=="image/png" || $ftype=="image/jpeg" || $ftype=="image/jpg")
								{
									$f=$_FILES['pic']['name'];
									$tf=$_FILES['pic']['tmp_name'];
									$t="images/".$f;
									if(move_uploaded_file($tf,$t))
									{
									  if(mysqli_query($c,"update doctorinfo set name='$name',email='$email',mobile_number='$mob',h_c_name='$hcname',specialization='$spec',address='$add',landmark='$lmark',c_v_name='$civi',state_name='$state',dpassword='$pwd',dphoto='$f', dept_id='$deptn', qualification='$qual' where id= $uid "))
										 {                   
											header("location:dprofile.php");
										 }
										else
										 {
											 
											 echo "sorry ! please retry... ";
										 } 	
										 
									}
									else
									{
										echo"error in file uploading... ";
									}
									
								}
								else
								{
									echo"file is not correct formate";
								}
									
								
						   }
						 
		        }
				
			  }
			?>
         
        

        


      </div>
      
    </div>
    
  </div>
  
</body>

</html>
 

<?php
	}
	else
	{
		header("location:../signin.php");
	}
	ob_end_flush();
?>
<?php
    session_start();
	  if(!empty($_SESSION["demo"] or $_SESSION["udemo"]))
	  {
          
?>	  
		  
		  
		 
<!DOCTYPE html>
<html lang="en">

<head>

  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="">
  
  <title>Logout</title>
  <link href="css/bootstrap.min.css" rel="stylesheet">
  <link href="css/dataTables.bootstrap4.css" rel="stylesheet">
  <link href="css/sb-admin.css" rel="stylesheet">

</head>

<body id="page-top">

  <nav class="navbar navbar-expand navbar-dark bg-dark static-top">
    <a class="navbar-brand mr-1" href="dindex.php">Welcome Doctor</a>
  </nav>

  <div id="wrapper">
    <ul class="sidebar navbar-nav text-light">
	<li class="nav-item ">
        <a class="nav-link" href="../index.php">
          <span>Home</span>
        </a>
      </li>
      <li class="nav-item ">
        <a class="nav-link" href="dprofile.php">
          <span>Profile</span>
        </a>
      </li>
	   <li class="nav-item ">
        <a class="nav-link" href="dexperience.php">
          <span>Experience</span>
        </a>
      </li>
	   <li class="nav-item ">
        <a class="nav-link" href="dmetting.php">
          <span>Metting</span>
        </a>
      </li>
	   <li class="nav-item ">
        <a class="nav-link" href="#">
          <span>Appointment</span>
        </a>
      </li>
	   <li class="nav-item ">
        <a class="nav-link" href="logout.php">
          <span>logout</span>
        </a>
      </li>
	   
      
    </ul>

    <div id="content-wrapper">

      <div class="container-fluid">
	  <div class="container text-center mt-2 mb-4 bg-success">
		          <h2>Logout</h2>
		   </div>
	   <div class="row">
	    <?php
				session_destroy();
		  header("location:../signin.php");
	    ?>
	   </div>
	  
	  
	  
	  
	  
	     
        


      </div>
      
    </div>
    
  </div>
  
</body>

</html>
<?php
		  }		  
	  else
	{
		header("location:../index.php");
	}
?>
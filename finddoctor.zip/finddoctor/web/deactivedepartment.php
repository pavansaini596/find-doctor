<?php
   session_start();
   if(!empty($_SESSION["sdemo"]))
   {
	  
	  $ddi= $_REQUEST["id"];
	  
	  $c=mysqli_connect("localhost","root","","doctor");
		if($c==false)
		{
		   die("Database connection error");
	   }

	    if(mysqli_query($c,"update department set d_status='Deactive' where id=$ddi"))
			 {
			   header("location:department.php");
			  }
			 else
			 {
				 
				 echo "sorry ! please retry. ";
			 }
   }
   else
   {
	   header("location:../signin.php");
   }
?>
<?php
 
    session_start();
	  if(!empty($_SESSION["demo"]))
	  {
		  $uid=$_SESSION["demo"];
		$c=mysqli_connect("localhost","root","","doctor");
			  if($c==false)
			  {
				  die("Database connection error");
			  }
			  
?>
<!DOCTYPE html>
<html lang="en">

<head>

  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="">
  
  <title>Docter </title>
  <link href="css/bootstrap.min.css" rel="stylesheet">
  <link href="css/dataTables.bootstrap4.css" rel="stylesheet">
  <link href="css/sb-admin.css" rel="stylesheet">

</head>

<body id="page-top">

  <nav class="navbar navbar-expand navbar-dark bg-dark static-top">
    <a class="navbar-brand mr-1" href="dindex.php">Welcome Doctor</a>
  </nav>

  <div id="wrapper">
    <ul class="sidebar navbar-nav text-light">
	   <li class="nav-item ">
        <a class="nav-link" href="../index.php">
          <span>Home</span>
        </a>
      </li>
      <li class="nav-item ">
        <a class="nav-link" href="dprofile.php">
          <span>Profile</span>
        </a>
      </li>
	   <li class="nav-item ">
        <a class="nav-link" href="dexperience.php">
          <span>Experience</span>
        </a>
      </li>
	   <li class="nav-item ">
        <a class="nav-link" href="dmetting.php">
          <span>Metting</span>
        </a>
      </li>
	   <li class="nav-item ">
        <a class="nav-link" href="dappointment.php">
          <span>Appointment</span>
        </a>
      </li>
	   <li class="nav-item ">
        <a class="nav-link" href="logout.php">
          <span>logout</span>
        </a>
      </li>
	   
      
    </ul>

    <div id="content-wrapper">

      <div class="container-fluid">
	  
	  
	  
        <div class="container text-center bg-danger">
		  <?php
		     $query=mysqli_query($c,"select * from doctorinfo where id='$uid'");
			  $count=mysqli_num_rows($query);
			  if($count>=1)
			  {
				   $r=mysqli_fetch_row($query);
				    echo"<h1>Welcome&nbsp;".$r[1]."</h1>";
						
			  }
		   ?>
		</div>
		<div class="row">
          <div class="col-xl-3 col-sm-6 mb-3">
            <div class="card text-white bg-primary o-hidden h-100">
              <div class="card-body">
                <div class="card-body-icon">
                 
                </div>
                <div class="mr-5">Profile</div>
              </div>
              <a class="card-footer text-white clearfix small z-1" href="dprofile.php">
                <span class="float-left">View Details</span>
                <span class="float-right">
                 
                </span>
              </a>
            </div>
          </div>
          <div class="col-xl-3 col-sm-6 mb-3">
            <div class="card text-white bg-warning o-hidden h-100">
              <div class="card-body">
                <div class="card-body-icon">
                 
                </div>
                <div class="mr-5">Experience</div>
              </div>
              <a class="card-footer text-white clearfix small z-1" href="dexperience.php">
                <span class="float-left">View Details</span>
                <span class="float-right">
                 
                </span>
              </a>
            </div>
          </div>
          <div class="col-xl-3 col-sm-6 mb-3">
            <div class="card text-white bg-success o-hidden h-100">
              <div class="card-body">
                <div class="card-body-icon">
                  
                </div>
                <div class="mr-5">Metting</div>
              </div>
              <a class="card-footer text-white clearfix small z-1" href="dmetting.php">
                <span class="float-left">View Details</span>
                <span class="float-right">
                  
                </span>
              </a>
            </div>
          </div>
          <div class="col-xl-3 col-sm-6 mb-3">
            <div class="card text-white bg-danger o-hidden h-100">
              <div class="card-body">
                <div class="card-body-icon">
                
                </div>
                <div class="mr-5">Appointment</div>
              </div>
              <a class="card-footer text-white clearfix small z-1" href="dappointment.php">
                <span class="float-left">View Details</span>
                <span class="float-right">

                </span>
              </a>
            </div>
          </div>
		  <div class="col-xl-3 col-sm-6 mb-3">
            <div class="card text-white bg-primary o-hidden h-100">
              <div class="card-body">
                <div class="card-body-icon">

                </div>
                <div class="mr-5">Logout</div>
              </div>
              <a class="card-footer text-white clearfix small z-1" href="logout.php">
                <span class="float-left">View Details</span>
                <span class="float-right">
                  
                </span>
              </a>
            </div>
          </div>
        </div>
       </div>    

        


      </div>
      
    </div>
    
  
  
</body>

</html>

<?php
	  }	  
  else
	{
		header("location:../signin.php");
	}
?>
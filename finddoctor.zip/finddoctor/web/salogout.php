
<?php
      session_start();
	  if(!empty($_SESSION["sdemo"]))
	  {
		 
		  session_destroy();
		  header("location:../superadmin.php");
	  }
	  		  
	  else
	{
		header("location:../index.php");
	}
?>	  
		  
	
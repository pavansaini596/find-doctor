<?php
	session_start();
	if(!empty($_SESSION["demo"]))
	{
			
			$uid=$_SESSION["demo"];
			$apid=$_REQUEST["id"];
			
			$c=mysqli_connect("localhost","root","","doctor");
	    	  if($c==false)
			   {
				  die("Database connection error");
			   }
			     if(isset($_POST["sub"]))
						  {
							  $status=$_POST["status"];
							 /* echo $status;
							  exit();*/
							$query=mysqli_query($c,"select * from appointment where id='$apid'");
							$count=mysqli_num_rows($query);
							if($count>=1)
							{
								$r=mysqli_fetch_row($query);
								$st=$r[8];
								
							 /*echo $status."<br>".$st;
						  exit();*/
						  
						    if($st!="Complete")
							{
							  
							   if($status=="Cancel" && $st!="Confirm")
							    {
								   if(mysqli_query($c,"update appointment set app_status='Cancel' where id='$apid'"))
									  {
										  header("location:dappointment.php");
										  
									  }
									 else
										{
										  echo "appointment not cancel";
										}
							    } 
							  else if($status=="Confirm" && $st!="Cancel")  
								 {
								   if(mysqli_query($c,"update appointment set app_status='Confirm' where id='$apid'"))
									  {
										  header("location:dappointment.php");
										 
									  }
									 else
										{
										  echo "appointment not confirm";
										}
							      } 
                            	 else if($status=="Cancel" && $st=="Confirm")  
								 {
								    header("location:dappointment.php");
								 } 
                            	
								
							     else  
								 {
								     $q=mysqli_query($c,"select * from appointment where id='$apid'");
									   $count=mysqli_num_rows($q);
								       if($count>=1)
									   { 
								          $r=mysqli_fetch_row($q);
										   $d=$r[12];
										   if(empty($d) || $d== null)
										   {
										        header("location:dappointmentedit.php?id=$r[0]");
										   }
										   else
										    {
												 if(mysqli_query($c,"update appointment set app_status='Complete' where id='$apid'"))
												 {
												   header("location:dappointment.php");
												 }
                                            }
									   }
									
							     }
								 
							 
							}
							else
							{
								header("location:dappointment.php");
								
							}
						  }
            }
	}
	else
	{
		header("location:../signin.php");
	}			  
?>
<?php
  ob_start();
      session_start();
	if(!empty($_SESSION["sdemo"]))
	{
		
	 $sid=$_SESSION["sdemo"];
	   $c=mysqli_connect("localhost","root","","doctor");
		if($c==false)
		{
		   die("Database connection error");
	   }
?>
<html>
   <head>
          <title>super admin panel</title>
			<meta charset="utf-8">
		  <meta http-equiv="X-UA-Compatible" content="IE=edge">
		  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
		  <meta name="description" content="">
		   <link href="css/bootstrap.min.css" rel="stylesheet">
		  <link href="css/dataTables.bootstrap4.css" rel="stylesheet">
		  <link href="css/sb-admin.css" rel="stylesheet">
		   <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
		   <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
		   <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>

			
	</head>
<body>
    <?php
	  
	   include("sheader.php");
	   
	?>
	<!--<body id="page-top">

  <nav class="navbar navbar-expand navbar-dark bg-dark static-top">
    <a class="navbar-brand mr-1" href="sindex.php">Welcome Super Admin</a>
  </nav>

  <div id="wrapper">
    <ul class="sidebar navbar-nav text-light">
	<li class="nav-item ">
        <a class="nav-link" href="../index.php">
          <span>Home</span>
        </a>
      </li>
      <li class="nav-item ">
        <a class="nav-link" href="department.php">
          <span>Department </span>
        </a>
      </li>
	   <li class="nav-item ">
        <a class="nav-link" href="#">
          <span>Experience</span>
        </a>
      </li>
	   <li class="nav-item ">
        <a class="nav-link" href="#">
          <span>Metting</span>
        </a>
      </li>
	   <li class="nav-item ">
        <a class="nav-link" href="#">
          <span>Appointment</span>
        </a>
      </li>
	   <li class="nav-item ">
        <a class="nav-link" href="salogout.php">
          <span>logout</span>
        </a>
      </li>
	   
      
    </ul>-->

    <div id="content-wrapper">

      <div class="container-fluid">
	      <div class="container text-center bg-danger pb-1 mb-4">
		  <?php
		     $query=mysqli_query($c,"select * from supadmin where id='$sid'");
			  $count=mysqli_num_rows($query);
			  if($count>=1)
			  {
				   $r=mysqli_fetch_row($query);
				    echo"<h1>Welcome&nbsp;".$r[1]."</h1>";
						
			  }
		   ?>
		</div>
	  
	  
       
		  
		
		<div class="row">
          <div class="col-xl-3 col-sm-6 mb-3">
            <div class="card text-white bg-primary o-hidden h-100">
              <div class="card-body">
                <div class="card-body-icon">
                 
                </div>
                <div class="mr-5">Department</div>
				
              </div>
              <a class="card-footer text-white clearfix small z-1" href="department.php">
                <span class="float-left">View Details</span>
                <span class="float-right">
                 
                </span>
              </a>
            </div>
          </div>
          <div class="col-xl-3 col-sm-6 mb-3">
            <div class="card text-white bg-warning o-hidden h-100">
              <div class="card-body">
                <div class="card-body-icon">
                 
                </div>
                <div class="mr-5">Doctors</div>
              </div>
              <a class="card-footer text-white clearfix small z-1" href="doctorslist.php">
                <span class="float-left">View Details</span>
                <span class="float-right">
                 
                </span>
              </a>
            </div>
          </div>
          <div class="col-xl-3 col-sm-6 mb-3">
            <div class="card text-white bg-success o-hidden h-100">
              <div class="card-body">
                <div class="card-body-icon">
                  
                </div>
                <div class="mr-5">Patient</div>
              </div>
              <a class="card-footer text-white clearfix small z-1" href="patientlist.php">
                <span class="float-left">View Details</span>
                <span class="float-right">
                  
                </span>
              </a>
            </div>
          </div>
          <div class="col-xl-3 col-sm-6 mb-3">
            <div class="card text-white bg-danger o-hidden h-100">
              <div class="card-body">
                <div class="card-body-icon">
                
                </div>
                <div class="mr-5">Appointment</div>
              </div>
              <a class="card-footer text-white clearfix small z-1" href="sappointment.php">
                <span class="float-left">View Details</span>
                <span class="float-right">

                </span>
              </a>
            </div>
          </div>
		  <div class="col-xl-3 col-sm-6 mb-3">
            <div class="card text-white bg-primary o-hidden h-100">
              <div class="card-body">
                <div class="card-body-icon">

                </div>
                <div class="mr-5">Logout</div>
              </div>
              <a class="card-footer text-white clearfix small z-1" href="salogout.php">
                <span class="float-left">View Details</span>
                <span class="float-right">
                  
                </span>
              </a>
            </div>
          </div>
        </div>
       </div>    

        
         

      </div>
      
    </div>
    
  
  
</body>

</html>
<?php
   }
   else
   {
       header("location:../signin.php");
   }
   
ob_end_flush();
?>
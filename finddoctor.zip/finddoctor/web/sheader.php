
<!DOCTYPE html>
<html lang="en">

<head>

  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="">
   <link href="css/bootstrap.min.css" rel="stylesheet">
  <link href="css/dataTables.bootstrap4.css" rel="stylesheet">
  <link href="css/sb-admin.css" rel="stylesheet">
   <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
   <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
   <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>

</head>

<body id="page-top">

  <nav class="navbar navbar-expand navbar-dark bg-dark static-top">
    <a class="navbar-brand mr-1" href="sindex.php">Welcome Super Admin</a>
  </nav>

  <div id="wrapper">
    <ul class="sidebar navbar-nav text-light">
	
	  <li class="nav-item ">
        <a class="nav-link" href="../index.php">
          <span>Web Home</span>
        </a>
      </li>
	  <li class="nav-item ">
        <a class="nav-link" href="sindex.php">
          <span>Dashboard</span>
        </a>
      </li>
      <li class="nav-item ">
        <a class="nav-link" href="department.php">
          <span>Department </span>
        </a>
      </li>
	   <li class="nav-item ">
        <a class="nav-link" href="doctorslist.php">
          <span>Doctors</span>
        </a>
      </li>
	   <li class="nav-item ">
        <a class="nav-link" href="patientlist.php">
          <span>Patients</span>
        </a>
      </li>
	  	<li class="nav-item ">
        <a class="nav-link" href="sappointment.php">
          <span>Appointment</span>
        </a>
      </li>
	   <li class="nav-item">
        <a class="nav-link" href="salogout.php">
          <span>logout</span>
        </a>
      </li>
	   
      
    </ul>



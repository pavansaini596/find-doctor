
<?php
   session_start();
   if(!empty($_SESSION["sdemo"]))
   {
	  
 ?>
<!DOCTYPE html>

<html>
 <head>
  
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="">
  
  <title> Patient details</title>
  <link href="css/bootstrap.min.css" rel="stylesheet">
  <link href="css/dataTables.bootstrap4.css" rel="stylesheet">
  <link href="css/sb-admin.css" rel="stylesheet">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
  
   <?php
   include("sheader.php");
   ?>
</head>

  <?php
     
     $sid=$_SESSION["sdemo"];
	  $c=mysqli_connect("localhost","root","","doctor");
		if($c==false)
		{
		   die("Database connection error");
	    }
	   
  ?>
    <div id="content-wrapper">

         <div class="container-fluid">
		 <div class="container text-center mt-2 mb-4 bg-success">
		          <h2>Appointment Details</h2>
		   </div>
		    <div class="row mt-3">
			  <div class="container-fluid " style="font-size:30px;" >
			   <?php
			   echo'  <div class="row mt-3">
			  <div class="container-fluid " style="font-size:30px;" >';
			  
				   $quer=mysqli_query($c,"select count(id) as total from appointment");
				      $co=mysqli_fetch_assoc($quer);
					  $qu=mysqli_query($c,"select count(id) as active from appointment where app_status='Pending'");
				      $cou=mysqli_fetch_assoc($qu);
					   $que=mysqli_query($c,"select count(id) as deactive from appointment where app_status='Cancel'");
				      $coun=mysqli_fetch_assoc($que);
					  $querc=mysqli_query($c,"select count(id) as conf from appointment where app_status='Confirm'");
				      $counc=mysqli_fetch_assoc($querc);
					   $querm=mysqli_query($c,"select count(id) as conm from appointment where app_status='Complete'");
				      $counm=mysqli_fetch_assoc($querm);
				  echo'<span class="badge badge-pill badge-info">Total&nbsp;'.$co["total"].'</span>
				   <span class="badge badge-pill badge-danger">Cancel &nbsp;'.$coun["deactive"].'</span>
				   <span class="badge badge-pill badge-warning">Pending &nbsp;'.$cou["active"].'</span>
				  <span class="badge badge-pill badge-success">Confirm &nbsp;'.$counc["conf"].'</span>
				  <span class="badge badge-pill badge-success">Complete &nbsp;'.$counm["conm"].'</span>
				  
               ';
			   ?>
             </div>
			</div>
	          
				
			  
			  </div>
			     
			</div>

			  
			

       </div>
	 
	</div>
  </body>
<?php
  }
 
   else
   {
       header("location:../signin.php");
   }

?>

<?php
   session_start();
   if(!empty($_SESSION["sdemo"]))
   {
	  
 ?>
<!DOCTYPE html>

<html>
 <head>
  
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="">
  
  <title> Department details</title>
  <link href="css/bootstrap.min.css" rel="stylesheet">
  <link href="css/dataTables.bootstrap4.css" rel="stylesheet">
  <link href="css/sb-admin.css" rel="stylesheet">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
  <script>
		$(document).ready(function(){
		  $("#myInput").on("keyup", function() {
			var value = $(this).val().toLowerCase();
			$("#myTable tr").filter(function() {
			  $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
			});
		  });
		});
</script>
   <?php
   include("sheader.php");
   ?>
</head>

  <?php
     
     $sid=$_SESSION["sdemo"];
	  $c=mysqli_connect("localhost","root","","doctor");
		if($c==false)
		{
		   die("Database connection error");
	   }
	   
  ?>
    <div id="content-wrapper">

         <div class="container-fluid">
		 <div class="container text-center mt-2 mb-4 bg-success">
		          <h2>Department Details</h2>
				  
		   </div>
		    <div class="row">
			  <div class="container-fluid " style="font-size:30px;" >
			   <?php
			   {
				   $query=mysqli_query($c,"select count(id) as total from department");
				      $co=mysqli_fetch_assoc($query);
					  $qu=mysqli_query($c,"select count(id) as active from department where d_status='Active'");
				      $cou=mysqli_fetch_assoc($qu);
					   $que=mysqli_query($c,"select count(id) as deactive from department where d_status='deactive'");
				      $coun=mysqli_fetch_assoc($que);
				  echo'<span class="badge badge-pill badge-info">Total&nbsp;'.$co["total"].'</span>
				   <span class="badge badge-pill badge-success">Active &nbsp;'.$cou["active"].'</span>
				   <span class="badge badge-pill badge-danger">Deactive &nbsp;'.$coun["deactive"].'</span>';
               }
			   ?>
             </div>
			</div>
	        <div class="row mt-4">
			  
				 <div class="col-lg-4 col-md-6 col-sm-6 "><button type="button" class="btn btn-success " data-toggle="collapse" data-target="#adddepartment">Add New Department</button>
				  <div id="adddepartment" class="collapse">
						 <form action='' method="post" enctype="multipart/form-data">
							   <br><div class="form-group">
								<label>Department Name</label>
								<input type="text" class="form-control" name="dept">
							  </div>
							   <div class="form-group">
								<label>image</label>
								<input type="file" class="form-control" name="pic">
							  </div>
							  <button type="submit" class="btn btn-success" name="addpic">Add Department</button>
							  							  
						 </form>
					  
					  
					 </div>
				 
				 
				  <?php
						if(isset($_POST["addpic"]))
					     {
							$name=$_POST["dept"]; 
							if(empty($_FILES['pic']['name']))
								{
								  echo" <div class='alert alert-danger alert-dismissible'>
									  <button type='button' class='close' data-dismiss='alert'>&times;</button>
									  <strong>Empty file ! Please retry and select jpg, png and jpeg file</strong>
									   </div>";
								}
							else
							 {
								 $ftype=$_FILES['pic']['type'];
							      if($ftype=="image/png" || $ftype=="image/jpg" || $ftype=="image/jpeg") 
								  {
									  $n=$_FILES['pic']['name'];
									  $tl=$_FILES['pic']['tmp_name'];
									  $l=$_FILES="deptimage/".$n;
									  if(move_uploaded_file($tl,$l))
									  {
										  if(mysqli_query($c,"insert into department (department_name,department_img,d_status) values('$name','$n','Active')"))
										  {
											   header("location:department.php");
											  /*echo" <div class='alert alert-success alert-dismissible'>
											  <button type='button' class='close' data-dismiss='alert'>&times;</button>
											  <strong>Your Department Successfully Upload</strong>
											   </div>";*/
												  
									  }
									  else
									  {
										  echo" <div class='alert alert-danger alert-dismissible'>
									  <button type='button' class='close' data-dismiss='alert'>&times;</button>
									  <strong>Error in file uploading....</strong>
									   </div>";
									  }
								  }	
                                  else
								  {
									  echo" <div class='alert alert-danger alert-dismissible'>
									  <button type='button' class='close' data-dismiss='alert'>&times;</button>
									  <strong>File is not in correct format! Please retry and select jpg, png and jpeg file</strong>
									   </div>";
								  }									  
						   	 }								
								
					        }
						 }
					 ?>
				   </div>
				    
				   <!--<div class="col-lg-4 col-md-6 col-sm-6 mt-lg-0 mt-3 "><button type="button" class="btn btn-warning " data-toggle="collapse" data-target="#edit">Edit Detail</button>
				  <div id="edit" class="collapse">
				         <?php
						       
						      // $did=$_REQUEST["id"];
						     // $query=mysqli_query($c,"select * from department where id='$did'");
							  // $count=mysqli_num_rows($query);
							  // if($count>=1)
							  // {
								   // $r=mysqli_fetch_row($query);
						
						          // echo" <form action='' method='post' enctype='multipart/form-data'>
							       // <br><div class='form-group'>
								    // <label>Department Name</label>
								    // <input type='text' class='form-control' name='dept' value='$r[1]'>
							      // </div>
							       // <div class='form-group'>
								   // <label>image</label>
								    // <img src='deptimage/$r[2]'width='70' height='70''>
								   // </div>
								   // <div class='form-group'>
								   // <input type='file' class='form-control' name='pic'>
								  
							      // </div>
							      // <button type='submit' class='btn btn-warning' name='update'>Update</button>
							  							  
						         // </form>";
					          // }
					     // ?>
					 </div>
					 
			  </div>-->
			 </div><br>
			 <div>
			 <input id="myInput" type="text" placeholder="Search..">
			 </div>
			  <div class="table-responsive-sm mt-5">          
			  <table class="table table-bordered  table-hover">
				
				  <thead class="pr-0 thead-dark">
				   <tr>
					<th>Department Image</th>
					<th>Department Name</th>
					<th>Edit Details</th>
					<th>Delete</th>
					<th>Status</th>
					<th>Active / Deactive</th>
					
				  </tr>
				</thead>
				<?php
				  $query=mysqli_query($c,"select * from department order by id desc");
				  $count=mysqli_num_rows($query);
				  if($count>=1)
				  {
					  while($r=mysqli_fetch_row($query))
					  {
						  echo"<tbody id='myTable'>
						       <tr>
							   <td><img src='deptimage/$r[2]'width='70' height='70''></td>
							     <td> $r[1]</td>
							     <td><a href='editdepartment.php?id=$r[0]'><button type='button' class='btn btn-warning role='button'>Edit Detail</button></a></td>
								  <td><a href='deletedepartment.php?id=$r[0]'><button type='button' class='btn btn-danger role='button'>Delete</button></a></td>
								  <td>$r[3]</td>";
						 if($r[3]=="Active")
						 {
					           echo"<td><a href='deactivedepartment.php?id=$r[0]'><button type='button' class='btn btn-danger role='button'>Deactive</button></a></td>
								 
							 ";
						 }
						 else 
						 {
							echo"<td><a href='activedepartment.php?id=$r[0]'><button type='button' class='btn btn-success role='button'>Active</button></a></td>
							 "; 
						 }
						 echo"</tr>
						    </tbody>";
						/* else
						 {
							echo"<tbody class='bg-warning text-white' id='myTable'>
						       <tr>
							   <td><img src='deptimage/$r[2]'width='70' height='70''></td>
							     <td> $r[1]</td>
							     <td><a href='editdepartment.php?id=$r[0]'><button type='button' class='btn btn-warning role='button'>Edit Detail</button></a></td>
							     <td><a href='deletedepartment.php?id=$r[0]'><button type='button' class='btn btn-danger role='button'>Delete</button></a></td>
							      <td><a href='deactivedepartment.php?id=$r[0]'><button type='button' class='btn btn-danger role='button'>Deactive</button></a></td>
								  <td><a href='activedepartment.php?id=$r[0]'><button type='button' class='btn btn-success role='button'>Active</button></a></td>
							 
                               </tr>
						    </tbody>"; 
						 }*/
					  }
				  }
				?>
			  </table>
			  </div>
			     
			</div>

			  
			

       </div>
	 
	</div>
  </body>
<?php
  }
 
   else
   {
       header("location:../signin.php");
   }

?>
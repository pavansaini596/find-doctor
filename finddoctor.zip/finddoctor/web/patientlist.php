
<?php
   session_start();
   if(!empty($_SESSION["sdemo"]))
   {
	  
 ?>
<!DOCTYPE html>

<html>
 <head>
  
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="">
  
  <title> Patient details</title>
  <link href="css/bootstrap.min.css" rel="stylesheet">
  <link href="css/dataTables.bootstrap4.css" rel="stylesheet">
  <link href="css/sb-admin.css" rel="stylesheet">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
  <script>
		$(document).ready(function(){
		  $("#myInput").on("keyup", function() {
			var value = $(this).val().toLowerCase();
			$("#myTable tr").filter(function() {
			  $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
			});
		  });
		});
</script>
   <?php
   include("sheader.php");
   ?>
</head>

  <?php
     
     $sid=$_SESSION["sdemo"];
	  $c=mysqli_connect("localhost","root","","doctor");
		if($c==false)
		{
		   die("Database connection error");
	   }
	   
  ?>
    <div id="content-wrapper">

         <div class="container-fluid">
		 <div class="container text-center mt-2 mb-4 bg-success">
		          <h2>Patient Details</h2>
		   </div>
		    <div class="row mt-3">
			  <div class="container-fluid " style="font-size:30px;" >
			   <?php
			   {
				   $query=mysqli_query($c,"select count(id) as total from userinfo");
				      $co=mysqli_fetch_assoc($query);
					  $qu=mysqli_query($c,"select count(id) as active from userinfo where acc_status='Active'");
				      $cou=mysqli_fetch_assoc($qu);
					   $que=mysqli_query($c,"select count(id) as deactive from userinfo where acc_status='Deactive'");
				      $coun=mysqli_fetch_assoc($que);
				  echo'<span class="badge badge-pill badge-info">Total&nbsp;'.$co["total"].'</span>
				   <span class="badge badge-pill badge-success">Active &nbsp;'.$cou["active"].'</span>
				   <span class="badge badge-pill badge-danger">Deactive &nbsp;'.$coun["deactive"].'</span>';
               }
			   ?>
             </div>
			</div>
	          <input id="myInput" type="text" placeholder="Search..">
			  <div class="table-responsive-sm mt-5">          
			  <table class="table table-bordered  table-hover">
				
				  <thead class="pr-0 thead-dark">
				   <tr>
					<th>id</th>
					<th>Name</th>
					<th>Email</th>
					<th>Mobile Number</th>
					<th>Delete</th>
					<th>Status</th>
					<th>Active / Deactive</th>
					
				  </tr>
				</thead>
				<?php
				  $query=mysqli_query($c,"select * from userinfo order by id desc");
				  $count=mysqli_num_rows($query);
				  if($count>=1)
				  {
					  
					  while($r=mysqli_fetch_row($query))
					  {
						  echo"<tbody id='myTable'>
						       <tr>
							   <td>$r[0]</td>
							     <td> $r[1]</td>
								 <td> $r[2]</td>
								 <td> $r[3]</td>
							      <td><a href='deletepatient.php?id=$r[0]'><button type='button' class='btn btn-danger role='button'>Delete</button></a></td>
					              <td> $r[5]</td>";
						 if($r[5]=="Active")
						 {
					      echo"
							      <td><a href='deactivepatient.php?id=$r[0]'><button type='button' class='btn btn-danger role='button'>Deactive</button></a></td>
								  ";
						 }
						 else if($r[5]=="Deactive")
						 {
							echo"
								  <td><a href='activepatient.php?id=$r[0]'><button type='button' class='btn btn-success role='button'>Active</button></a></td>
							 
                               ";
						 }
						 echo"</tr>
						    </tbody>";
						 /*else
						 {
							echo"<tbody class='bg-primary text-white' id='myTable'>
						      <tr>
							   <td>$r[0]</td>
							     <td> $r[1]</td>
								 <td> $r[2]</td>
								 <td> $r[3]</td>
							      <td><a href='deletepatient.php?id=$r[0]'><button type='button' class='btn btn-danger role='button'>Delete</button></a></td>
							      <td><a href='deactivepatient.php?id=$r[0]'><button type='button' class='btn btn-danger role='button'>Deactive</button></a></td>
								  <td><a href='activepatient.php?id=$r[0]'><button type='button' class='btn btn-success role='button'>Active</button></a></td>
							 
                               </tr>
						    </tbody>";
						 }*/
					  }
				  }
				?>
			  </table>
			  </div>
			     
			</div>

			  
			

       </div>
	 
	</div>
  </body>
<?php
  }
 
   else
   {
       header("location:../signin.php");
   }

?>
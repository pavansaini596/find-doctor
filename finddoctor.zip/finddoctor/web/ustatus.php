<?php
    session_start();
	  if(!empty($_SESSION["udemo"]))
	  {
		  $uid=$_SESSION["udemo"];
		  $c=mysqli_connect("localhost","root","","doctor");
			  if($c==false)
			  {
				  die("Database connection error");
			  }
			  
?>
<!DOCTYPE html>
<html lang="en">

<head>

  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="">
  
  <title>Patient </title>
  <link href="css/bootstrap.min.css" rel="stylesheet">
  <link href="css/dataTables.bootstrap4.css" rel="stylesheet">
  <link href="css/sb-admin.css" rel="stylesheet">

</head>

<body id="page-top">

  <nav class="navbar navbar-expand navbar-dark bg-dark static-top">
    <a class="navbar-brand mr-1" href="uindex.php">Welcome Patient</a>
  </nav>

  <div id="wrapper">
    <ul class="sidebar navbar-nav text-light">
	<li class="nav-item ">
        <a class="nav-link" href="../index.php">
          <span>Web Home</span>
        </a>
      </li>
	<li class="nav-item ">
        <a class="nav-link" href="uindex.php">
          <span>Dashboard</span>
        </a>
      </li>
      <li class="nav-item ">
        <a class="nav-link" href="uprofile.php">
          <span>Profile</span>
        </a>
      </li>
	   
	   <li class="nav-item ">
        <a class="nav-link" href="uappointment.php">
          <span>Appointment</span>
        </a>
      </li>
	   <li class="nav-item ">
        <a class="nav-link" href="logout.php">
          <span>logout</span>
        </a>
      </li>
	   
      
    </ul>

    <div id="content-wrapper">

      <div class="container-fluid">
	  
	  
	  
        <div class="container text-center bg-danger">
		  
		</div>
		<div class="row ml-3">
          <?php
		     if(mysqli_query($c,"update userinfo set acc_status='Deactive' where id=$uid"))
			 {
				  
			   echo"Your account are successfully deactived. if you want active your account. Please contact support team.";
			    session_destroy();
			  }
			 else
			 {
				 
				 echo "sorry ! please retry. ";
			 }
		   ?>
          </div>
       
       </div>    

        


      </div>
      
    </div>
    
  </div>
  
</body>

</html>

<?php
	  }	  
  else
	{
		header("location:../signin.php");
	}
?>
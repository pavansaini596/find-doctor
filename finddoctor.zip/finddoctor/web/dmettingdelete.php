<?php
 session_start();
	if(!empty($_SESSION["demo"]))
	{ 
     $mid=$_REQUEST["id"];
	 $c=mysqli_connect("localhost","root","","doctor");
	  if($c==false)
	   {
		  die("Database connection error");
	   }
	 if(mysqli_query($c,"delete from metting where id='$mid'"))
	 {
		  header("location:dmetting.php");
	 }
	}
	else
	{
		header("location:../signin.php");
	}
?>
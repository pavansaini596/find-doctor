<?php
   ob_start();

    session_start();
	
	if(!empty($_SESSION["udemo"]))
	{
		
		$uid=$_SESSION["udemo"];
		$ap=$_REQUEST["id"];
?>
<!DOCTYPE html>
<html lang="en">

<head>

  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="">
  
  <title></title>
  <link href="css/bootstrap.min.css" rel="stylesheet">
  <link href="css/dataTables.bootstrap4.css" rel="stylesheet">
  <link href="css/sb-admin.css" rel="stylesheet">
   <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>

</head>

<body id="page-top">

  <nav class="navbar navbar-expand navbar-dark bg-dark static-top">
    <a class="navbar-brand mr-1" href="uindex.php">Welcome Patient</a>
  </nav>

  <div id="wrapper">
    <ul class="sidebar navbar-nav text-light">
	<li class="nav-item ">
        <a class="nav-link" href="../index.php">
          <span>Home</span>
        </a>
      </li>
      <li class="nav-item ">
        <a class="nav-link" href="uprofile.php">
          <span>Profile</span>
        </a>
      </li>
	   
	   <li class="nav-item ">
        <a class="nav-link" href="uappointment.php">
          <span>Appointment</span>
        </a>
      </li>
	   <li class="nav-item ">
        <a class="nav-link" href="logout.php">
          <span>logout</span>
        </a>
      </li>
	   
      
    </ul>

    <div id="content-wrapper">

      <div class="container-fluid">
	       <div class="container text-center mt-2 mb-2 bg-success">
		          <h2>Create Appointment</h2>
		   </div>
	     <?php
			
			$c=mysqli_connect("localhost","root","","doctor");
	    	  if($c==false)
			   {
				  die("Database connection error");
			   }
			   
			 $query=mysqli_query($c,"select * from metting where id=$ap");				  
			 $count=mysqli_num_rows($query);
			  if($count>=1)
			    {
				  $r=mysqli_fetch_row($query);
					  {
						    $didd=$r[1];
			           echo"<div class='col-sm-12 col-md-6 col-lg-6 mt-2'>
					           <form action='' method='post'>
									<div class='form-group '>
									    <label>Patient Name</label> 
										<input type='text' class='form-control' name='pname' required>
										 <label>Patient Father/Husband Name</label> 
										<input type='text' class='form-control' name='faname' required>
										<label>Patient Age</label> 
										<input type='tel' class='form-control' name='page' pattern='[0-9]{size='3' maxlength='3'}' required>
										<label>Hospital / Clinic Name</label> 
										<input type='text' class='form-control' name='name' value='$r[2]' required disabled>
										<input type='hidden' class='form-control' name='hname' value='$r[2]'>
										 <label> Metting Time</label> 
										<input type='text' class='form-control' name='time' value='$r[3]' required  disabled>
										<input type='hidden' class='form-control' name='mtime' value='$r[3]' >
								        <label> Appointment Time </label> 
										<input type='text' class='form-control' name='atime' placeholder='add time between $r[3]' required >
								        <label> Day </label> 
										<input type='text' class='form-control' name='day' value='$r[4]' required  disabled>
								        <label> Appointment Day</label> 
										<input type='text' class='form-control' name='aday' placeholder='$r[4]' required >
								         <label>Date</label> 
										<input type='date' class='form-control' name='adate' required >
								        <label>Fees</label> 
										<input type='text' class='form-control' name='fee' value='$r[5]' required  disabled >
										
										<input type='hidden' class='form-control' name='afee' value='$r[5]'>
										<select hidden class='form-control' name='status' >
                                          <option value='Pending' selected></option>	
                                        </select>";
										$query=mysqli_query($c,"select * from doctorinfo where id=$didd");				  
										 $count=mysqli_num_rows($query);
										  if($count>=1)
											{
											  $s=mysqli_fetch_row($query);
												  {
												    echo"<input type='hidden' name='did' value='$s[1]'>";
												  }
											}
													echo"</div>
									<button type='submit' class='btn btn-primary' name='capp'>Create Appointment</button>
								 </form>		
							</div>			  
						 ";
						  if(isset($_POST["capp"]))
						  {
							  $hname=$_POST["hname"];
							  $atime=$_POST["atime"];
							  $aday=$_POST["aday"];
							  $adate=$_POST["adate"];
							  $fee=$_POST["afee"];
							  $status=$_POST["status"];
							  $pname=$_POST["pname"];
							  $fname=$_POST["faname"];
							  $page=$_POST["page"]; 
							  $did=$_POST["did"];
						    if(mysqli_query($c,"insert into appointment (patient_id,doctor_id,hospital_name,app_time,day,date,fee,app_status,p_name,f_h_name,patient_age,doc_name) values('$uid','$r[1]','$hname','$atime','$aday','$adate','$fee','$status','$pname','$fname','$page','$did')"))
							  {
								  echo" <div class='alert alert-success alert-dismissible'>
											  <button type='button' class='close' data-dismiss='alert'>&times;</button>
											  <strong>Your Appointment Successfully Create</strong>
											   </div>";
							  }
							  else
							  {
								  echo" <div class='alert alert-danger alert-dismissible'>
									  <button type='button' class='close' data-dismiss='alert'>&times;</button>
									  <strong>Please Retry! Your Appointment Are Not Create.</strong>
									   </div>";
							  }
						  }			
                       }
		   	   }
						 				  
				  		    
								
						  
				         
		?>

      </div>
      
    </div>
    
  </div>
  
</body>

</html>
 

<?php
	}
	else
	{
		header("location:../signin.php");
	}
	ob_end_flush();
?>
<?php
   

    session_start();
	if(!empty($_SESSION["demo"]))
	{
		
?>
<!DOCTYPE html>
<html lang="en">

<head>

  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="">
  
  <title>Docter metting </title>
  <link href="css/bootstrap.min.css" rel="stylesheet">
  <link href="css/dataTables.bootstrap4.css" rel="stylesheet">
  <link href="css/sb-admin.css" rel="stylesheet">

</head>

<body id="page-top">

  <nav class="navbar navbar-expand navbar-dark bg-dark static-top">
    <a class="navbar-brand mr-1" href="dindex.php">Welcome Doctor</a>
  </nav>

  <div id="wrapper">
    <ul class="sidebar navbar-nav text-light">
	 <li class="nav-item ">
        <a class="nav-link" href="../index.php">
          <span>Web Home</span>
        </a>
      </li>
	  <li class="nav-item ">
        <a class="nav-link" href="dindex.php">
          <span>Dashbord</span>
        </a>
      </li>
      <li class="nav-item ">
        <a class="nav-link" href="dprofile.php">
          <span>Profile</span>
        </a>
      </li>
	   <li class="nav-item ">
        <a class="nav-link" href="dexperience.php">
          <span>Experience</span>
        </a>
      </li>
	   <li class="nav-item ">
        <a class="nav-link" href="dmetting.php">
          <span>Metting</span>
        </a>
      </li>
	   <li class="nav-item ">
        <a class="nav-link" href="dappointment.php">
          <span>Appointment</span>
        </a>
      </li>
	   <li class="nav-item ">
        <a class="nav-link" href="logout.php">
          <span>logout</span>
        </a>
      </li>
	   
      
    </ul>

    <div id="content-wrapper">

      <div class="container-fluid">
	  <div class="container text-center mt-2 mb-4 bg-success">
		          <h2>Metting</h2>
		   </div>
	   <div class="row">
	    <?php
			$uid=$_SESSION["demo"];
			$c=mysqli_connect("localhost","root","","doctor");
	    	  if($c==false)
			   {
				  die("Database connection error");
			   }
			     echo"
					<div class='col-sm-12 col-md-4 col-lg-4 mt-2'>
                        <form action='' method='post'>
                          <div class='form-group '>
						   <label>Hospital Name</label>
						   <input type='text' class='form-control' name='hname' placeholder='Enter Hospital Name'required>
						   <label> Time </label>
						   <input type='text' class='form-control' name='mtime' required>
						   <label>Day</label>
						   <input type='text' class='form-control' name='mday' required>
						   <label>Fee </label>
						   <input type='tel' class='form-control' name='fee' placeholder='Enter Your Fees'>
						  </div>
						   
						   <button type='submit' class='btn btn-primary' name='add'>Add Metting</button>
				   	 </form>
					 </div>	";
						  
					if(isset($_POST["add"]))
						 { 
							   $name=$_POST["hname"];
							   $mtime=$_POST["mtime"];
							   $mday=$_POST["mday"];
							   $fee=$_POST["fee"];
							   
							 $c=mysqli_connect("localhost","root","","doctor");
							 if($c==false)
							 {
								 die("database connection error");
							 }
							 if(mysqli_query($c,"insert into metting (doctor_id,hospital_name,m_time,day,fee) values('$uid','$name','$mtime','$mday','$fee')"))
							 {
								 header("location:dmetting.php");
								 
							 } 
							 else
							 {
								 echo"Sorry you metting time not add. Please retry";
							 }
						 }
			  		 echo"<div class='col-sm-12 col-md-8 col-lg-8 mt-2'>
						<div class='table-responsive'>
						  <table class='table'>
							<tr>
							     <th>Hospital Name</th>
								 <th>Time</th>
								 <th>Day</th>
								 <th>Fees</th>
								 <th>Edit</th>
								 <th>Delete</th>
						   </tr>";
						  	
                        $query=mysqli_query($c,"select * from metting where doctor_id='$uid'");
						 $count= mysqli_num_rows($query);
						 if($count>=1)
						 {
						   while($r=mysqli_fetch_row($query))
						   {   
							  echo"<tr>
							        <td>$r[2]</td>
									<td>$r[3]</td>
									<td>$r[4]</td>
									<td>$r[5]</td>
									<td> 
									<a href='dmettingedit.php?id=$r[0]'<button class='btn btn-primary' value=''>Edit</button></a>
									</td>
								     <td> 
									<a href='dmettingdelete.php?id=$r[0]'<button class='btn btn-primary' value=''>Delete</button></a>
									</td>
								   </tr>";
						   }
						 }

						echo"</table>
						</div>
                      </div>";				
	    ?>
	   </div>
	  
	  
	  
	  
	  
	     
        


      </div>
      
    </div>
    
  </div>
  
</body>

</html>
 

<?php
	}
	else
	{
		header("location:../signin.php");
	}
?>


<?php
   

    session_start();
	if(!empty($_SESSION["udemo"]))
	{
		
?>
<!DOCTYPE html>
<html lang="en">

<head>

  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="">
  
  <title>Patient profile</title>
  <link href="css/bootstrap.min.css" rel="stylesheet">
  <link href="css/dataTables.bootstrap4.css" rel="stylesheet">
  <link href="css/sb-admin.css" rel="stylesheet">

</head>

<body id="page-top">

  <nav class="navbar navbar-expand navbar-dark bg-dark static-top">
    <a class="navbar-brand mr-1" href="uindex.php">Welcome Patient</a>
  </nav>

  <div id="wrapper">
    <ul class="sidebar navbar-nav text-light">
	<li class="nav-item ">
        <a class="nav-link" href="../index.php">
          <span>Web Home</span>
        </a>
      </li>
	<li class="nav-item ">
        <a class="nav-link" href="uindex.php">
          <span>Dashboard</span>
        </a>
      </li>
      <li class="nav-item ">
        <a class="nav-link" href="uprofile.php">
          <span>Profile</span>
        </a>
      </li>
	   
	   <li class="nav-item ">
        <a class="nav-link" href="uappointment.php">
          <span>Appointment</span>
        </a>
      </li>
	   <li class="nav-item ">
        <a class="nav-link" href="logout.php">
          <span>logout</span>
        </a>
      </li>
	   
      
    </ul>

    <div id="content-wrapper">

      <div class="container-fluid">
	       <div class="container text-center mt-2 mb-2 bg-success">
		          <h2>Profile</h2>
		   </div>
	     <?php
			$uid=$_SESSION["udemo"];
			$c=mysqli_connect("localhost","root","","doctor");
	    	  if($c==false)
			   {
				  die("Database connection error");
			   }
			  $query=mysqli_query($c,"select * from userinfo where id='$uid'");
			  $count=mysqli_num_rows($query);
			  if($count>=1)
			  {
				   $r=mysqli_fetch_row($query);
				    echo"
					<div class='col-sm-12 col-md-6 col-lg-6 mt-2'>
                        <form action='' method='post'>
						            <div class='form-group '>
								        <label> Name</label> 
										<input type='text' class='form-control' name='name' value='$r[1]' required>
								        <label> Email</label> 
										<input type='email' class='form-control' name='email' value='$r[2]' required>
								        <label> Mobile Number</label> 
										<input type='tel'class='form-control' name='mob' value='$r[3]' pattern='[0-9]{10}' maxlength='10' minlength='10' size='10' required>
								        <label> Password</label> 
									    <input type='text' class='form-control' name='pwd' value='$r[4]' required>
									   
								    </div>
									<button type='submit' class='btn btn-primary' name='update'>Update</button>
									
                              </form> <br>  
							   <form action='ustatus.php' method='get'>
							   <button type='submit' class='btn btn-danger' name='deactive'>Deactive Account</button>
                               </form>							   
							   
					       </div>
						";				
			  }
			   if(isset($_POST["update"]))
		        {
						      $name=$_POST["name"];
							  $email=$_POST["email"];
							  $mob=$_POST["mob"];
							  $pwd=$_POST["pwd"];
							   
						  if(mysqli_query($c,"update userinfo set name='$name',email='$email',mobile_number='$mob',upassword='$pwd' where id= $uid"))
						 {                   
						    header("location:uprofile.php");
						 }
						else
						 {
							 
							 echo "sorry ! please retry. ";
						 } 
						 
		        }
				
		 	?>
      </div>
      
    </div>
    
  </div>
  
</body>

</html>
 

<?php
	}
	else
	{
		header("location:../signin.php");
	}
?>
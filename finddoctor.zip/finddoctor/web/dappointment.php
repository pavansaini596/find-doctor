<?php
   

    session_start();
	if(!empty($_SESSION["demo"]))
	{
		
?>
<!DOCTYPE html>
<html lang="en">

<head>

  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="">
  
  <title>Docter metting </title>
  <link href="css/bootstrap.min.css" rel="stylesheet">
  <link href="css/dataTables.bootstrap4.css" rel="stylesheet">
  <link href="css/sb-admin.css" rel="stylesheet">

</head>

<body id="page-top">

  <nav class="navbar navbar-expand navbar-dark bg-dark static-top">
    <a class="navbar-brand mr-1" href="dindex.php">Welcome Doctor</a>
  </nav>

  <div id="wrapper">
    <ul class="sidebar navbar-nav text-light">
	 <li class="nav-item ">
        <a class="nav-link" href="../index.php">
          <span>Web Home</span>
        </a>
      </li>
	  <li class="nav-item ">
        <a class="nav-link" href="dindex.php">
          <span>Dashbord</span>
        </a>
      </li>
      <li class="nav-item ">
        <a class="nav-link" href="dprofile.php">
          <span>Profile</span>
        </a>
      </li>
	   <li class="nav-item ">
        <a class="nav-link" href="dexperience.php">
          <span>Experience</span>
        </a>
      </li>
	   <li class="nav-item ">
        <a class="nav-link" href="dmetting.php">
          <span>Metting</span>
        </a>
      </li>
	   <li class="nav-item ">
        <a class="nav-link" href="dappointment.php">
          <span>Appointment</span>
        </a>
      </li>
	   <li class="nav-item ">
        <a class="nav-link" href="logout.php">
          <span>logout</span>
        </a>
      </li>
	   
      
    </ul>

    <div id="content-wrapper">

      <div class="container-fluid">
	  <div class="container text-center mt-2 mb-4 bg-success">
		          <h2>Appointment</h2>
		   </div>
		   <form class="d-none d-md-inline-block form-inline ml-auto mr-0 mr-md-3 my-2 my-md-0">
      <div class="input-group">
	  
        <input type="text" class="form-control" id="myInput" onkeyup="myFunction()"  placeholder="Rec. No. Search........" aria-label="Search" aria-describedby="basic-addon2">
        
      </div>
    </form>
	    <?php
			$uid=$_SESSION["demo"];
			$c=mysqli_connect("localhost","root","","doctor");
	    	  if($c==false)
			   {
				  die("Database connection error");
			   }
			   echo'  <div class="row mt-3">
			  <div class="container-fluid " style="font-size:25px;" >';
			  
				   $quer=mysqli_query($c,"select count(id) as total from appointment where doctor_id='$uid'");
				      $co=mysqli_fetch_assoc($quer);
					  $qu=mysqli_query($c,"select count(id) as active from appointment where doctor_id='$uid' and app_status='Pending'");
				      $cou=mysqli_fetch_assoc($qu);
					   $que=mysqli_query($c,"select count(id) as deactive from appointment where doctor_id='$uid' and app_status='Cancel'");
				      $coun=mysqli_fetch_assoc($que);
					  $querc=mysqli_query($c,"select count(id) as conf from appointment where doctor_id='$uid' and app_status='Confirm'");
				      $counc=mysqli_fetch_assoc($querc);
					   $querm=mysqli_query($c,"select count(id) as conm from appointment where doctor_id='$uid' and app_status='Complete'");
				      $counm=mysqli_fetch_assoc($querm);
				  echo'<span class="badge badge-pill badge-info">Total&nbsp;'.$co["total"].'</span>
				   <span class="badge badge-pill badge-danger">Cancel &nbsp;'.$coun["deactive"].'</span>
				   <span class="badge badge-pill badge-warning">Pending &nbsp;'.$cou["active"].'</span>
				  <span class="badge badge-pill badge-success">Confirm &nbsp;'.$counc["conf"].'</span>
				  <span class="badge badge-pill badge-success">Complete &nbsp;'.$counm["conm"].'</span>
				  </div>
				  </div>
			   <div class="table-responsive-sm mt-5 text-center">          
			        <table id="myTable"  class="table table-bordered  table-hover">
				
				  <thead class="pr-0 thead-dark">
				   <tr>
				   <th> Rec. No.:- </th>
				   <th> patient name </th>
				   	<th>Hospital Name</th>
					<th>Appointment Time</th>
					<th>Appointment Day</th>
					<th>Appointment Date</th>
					<th> Fees</th>
	                <th>Status</th>
					<th>Change Status</th>
					<th>View</th>
					<th>update</th>
			      </tr>
				</thead>';
			  $query=mysqli_query($c,"select * from appointment where doctor_id= $uid order by id desc" );				  
			 $count=mysqli_num_rows($query);
			  if($count>=1)
			    {
				  while($r=mysqli_fetch_row($query))
					  {
			           echo"
					          <tbody>
									   <tr>
									   <td>$r[0]</td>
									   <td>$r[9]</td>
									   <td>$r[3]</td>
										 <td>$r[4]</td>
										 <td>$r[5]</td>
										 <td>$r[6]</td>
										 <td>$r[7] </td>
										 <td>
										  <div>$r[8]</div>
										  </td>
										  <td>
										  <form action='status.php?id=$r[0]' method='post'>
										  <div class='form-group '>
										   <select class='form-control' name='status' required>
										       <!--<option value='$r[8]' selected>$r[8]</option>-->
											   <option value=''>Select any</option>
											    <option value='Cancel'>Cancel</option>
										       <option value='Confirm'> Confirm</option>
											   <option value='Complete'>Complete</option>
										   </select>
										    <button type='submit' class='btn btn-primary mt-1' name='sub'>Submit</button>
										  </div>
										</td>
										</form>
                                           <td>
										   
										    <a href='dappointmentview.php?id=$r[0]'<button class='btn btn-primary' value=''>View</button></a>
										  </td>
										 <td>
										   
										    <a href='dappointmentedit.php?id=$r[0]'<button class='btn btn-primary' value=''>Update</button></a>
										  </td>
									   </tr>
									</tbody>
										  
									
									  
						 ";
						 
						 
					  }
					  
			    }
				 echo"</table></div>";
				  
				  
	    ?>
	  
      </div>
    </div>
    
  </div>
  <script>
		function myFunction() {
		  var input, filter, table, tr, td, i, txtValue;
		  input = document.getElementById("myInput");
		  filter = input.value.toUpperCase();
		  table = document.getElementById("myTable");
		  tr = table.getElementsByTagName("tr");
		  for (i = 0; i < tr.length; i++) {
			td = tr[i].getElementsByTagName("td")[0];
			if (td) {
			  txtValue = td.textContent || td.innerText;
			  if (txtValue.toUpperCase().indexOf(filter) > -1) {
				tr[i].style.display = "";
			  } else {
				tr[i].style.display = "none";
			  }
			}       
		  }
		}
		
</script>
</body>

</html>
 

<?php
	}
	else
	{
		header("location:../signin.php");
	}
?>
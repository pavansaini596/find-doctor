
<?php
   

    session_start();
	if(!empty($_SESSION["demo"]))
	{
		
?>
<!DOCTYPE html>
<html lang="en">

<head>

  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="">
  
  <title>Docter experience edit</title>
  <link href="css/bootstrap.min.css" rel="stylesheet">
  <link href="css/dataTables.bootstrap4.css" rel="stylesheet">
  <link href="css/sb-admin.css" rel="stylesheet">

</head>

<body id="page-top">

  <nav class="navbar navbar-expand navbar-dark bg-dark static-top">
    <a class="navbar-brand mr-1" href="dindex.php">Welcome Doctor</a>
  </nav>

  <div id="wrapper">
    <ul class="sidebar navbar-nav text-light">
	 <li class="nav-item ">
        <a class="nav-link" href="../index.php">
          <span>Home</span>
        </a>
      </li>
      <li class="nav-item ">
        <a class="nav-link" href="dprofile.php">
          <span>Profile</span>
        </a>
      </li>
	   <li class="nav-item ">
        <a class="nav-link" href="dexperience.php">
          <span>Experience</span>
        </a>
      </li>
	   <li class="nav-item ">
        <a class="nav-link" href="dmetting.php">
          <span>Metting</span>
        </a>
      </li>
	   <li class="nav-item ">
        <a class="nav-link" href="dappointment.php">
          <span>Appointment</span>
        </a>
      </li>
	   <li class="nav-item ">
        <a class="nav-link" href="logout.php">
          <span>logout</span>
        </a>
      </li>
	   
      
    </ul>

    <div id="content-wrapper">

      <div class="container-fluid">
	  <div class="container text-center mt-2 mb-4 bg-success">
		          <h2>Experience</h2>
		   </div>
	   <div class="row">
	   
    

         <div class="container-fluid   mb-5">
	        <div class="row">
			  
				   <div class=" container col-lg-4 col-md-6 col-sm-6 mt-lg-0 mt-3 bg-primary display-5 text-center p-2 text-light font-weight-bold">
				         <?php
								$uid=$_SESSION["demo"];
								$exid=$_REQUEST["id"];
								$c=mysqli_connect("localhost","root","","doctor");
								  if($c==false)
								   {
									  die("Database connection error");
								   }
						       
						     $query=mysqli_query($c,"select * from experience where id=$exid");
							  $count=mysqli_num_rows($query);
							  if($count>=1)
							  {
								   $r=mysqli_fetch_row($query);
								       
						             echo" <form action='' method='post'>
									   <br><div class='form-group'>
										<label>Hospital Name</label>
										<input type='text' class='form-control' name='hname' value='$r[2]'>
									  </div>
									     <div class='form-group'>
										<label>Experience (year)</label>
										<input type='text' class='form-control' name='exp' value='$r[3]'>
									  </div>
									   <div class='form-group'>
										<label>From Date</label>
										<input type='date' class='form-control' name='fdate' value='$r[4]'>
									  </div>
									  <div class='form-group'>
										<label>To Date</label>
										<input type='date' class='form-control' name='tdate' value='$r[5]'>
									  </div>
									  <div class='form-group'>
										<label>Details</label>
										<input type='text' class='form-control' name='detail' value='$r[6]'>
									  </div>

									  <button type='submit' class='btn btn-warning text-center p-2 text-light font-weight-bold' name='update'>Update</button>
															  
									 </form>";
							  }        
			
					if(isset($_POST["update"]))
				      { 
						$name=$_POST["hname"];
						$exp=$_POST["exp"];
						$fdate=$_POST["fdate"];
						$tdate=$_POST["tdate"];
						$detail=$_POST["detail"];
			
						 
							  
						   if(mysqli_query($c,"update experience set hospital_name='$name',experience='$exp',frome_date='$fdate',to_date='$tdate',detail='$detail' where id=$exid"))
						   {
							   header("location:dexperience.php");
						   }   
						  
					}
			  			
	    ?>
	   </div>
	  
	  
	  
	  
	  
	     
        


      </div>
      
    </div>
    
  </div>
  
</body>

</html>
 

<?php
	}
	else
	{
		header("location:../signin.php");
	}
?>



<html>
<head>
             <title> home</title>
            <meta name="viewport" content="width=device-width, initial-scale=1">
			<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
			<meta name="keywords" content="" />
			<link rel="stylesheet" href="css/bootstrap.min.css"><!-- bootstrap-CSS -->
			<link rel="stylesheet" href="css/bootstrap-select.css"><!-- bootstrap-select-CSS -->
			<link href="css/style.css" rel="stylesheet" type="text/css" media="all" /><!-- style.css -->
			<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.7.2/css/all.css" integrity="sha384-fnmOCqbTlWIlj8LyTjo7mOUStjsKC4pOpQbqyi7RrhN7udi9RwhKkMHpvLbHG9Sr" crossorigin="anonymous">
			
			<link rel="stylesheet" href="css/bootstrap-select.css"><!-- bootstrap-select-CSS -->
			<link href="css/style.css" rel="stylesheet" type="text/css" media="all" /><!-- style.css -->
			<link rel="stylesheet" href="css/font-awesome.min.css" />
			<!--<link rel="stylesheet" href="css/font-awesome.min.css" /><!-- fontawesome-CSS -->
			<link href='//fonts.googleapis.com/css?family=Ubuntu+Condensed' rel='stylesheet' type='text/css'>
			<link href='//fonts.googleapis.com/css?family=Open+Sans:400,300,300italic,400italic,600,600italic,700,700italic,800,800italic' rel='stylesheet' type='text/css'>
             <script src="css/jquery.min.js"></script>
       
  			
			
</head>
<body>
    
	<?php
		include("header.php");
	?>
   <div class="main-content">
			<div class="w3-categories">
		    	 <h3>Browse Categories</h3>
					<div class="container">
						
							<?php
							
							$c=mysqli_connect("localhost","root","","doctor");
							if($c==false)
							{
								die ("error in connection");
							}

							$query=mysqli_query($c,"select * from department where d_status='Active' order by department_name");
						
							$count=mysqli_num_rows($query);
							if($count>=1)
							{
								  
								  while($r=mysqli_fetch_row($query))
								  {
								        
										 
												echo'<div class="col-md-3"> <div class=" focus-grid w3layouts-boder1">
													   <a class="btn-8" href="categories.php?id='.$r[0].'&dpt='.$r[1].'">
												    		<div class="focus-border">
																<div class="focus-layout">
												      			 <div class="focus-image img-fliud">  <img src="web/deptimage/'.$r[2].' "width=100vw height=100vw> </div>
																	<h4 class="clrchg"> '.$r[1].'</h4>
																</div>
															</div>
														  </a>
														</div>
						                          </div>';
									       

										   }
							}
                           
					?>

                          	</div>
					
						</div>
				
	
	
	<?php
	    include("footer.php");
	?>
   
</body>
</html>
<!-- <script type="text/javascript">
	$(document).ready(function()
	{
        $("#btn").click(function(){
		debugger;
         $("#da").css("display","none");

         $("#agileinfo_search").val('hello');
         });
	});
	
</script> -->
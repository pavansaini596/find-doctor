<?php
 include("header.php");

?>

<div class="agileinfo-ads-display col-md-9">
					<div class="wrapper">					
					<div class="bs-example bs-example-tabs" role="tabpanel" data-example-id="togglable-tabs">
					 <ul id="myTab" class="nav nav-tabs nav-tabs-responsive" role="tablist">
						<li role="presentation" class="active">
						  <a href="#home" id="home-tab" role="tab" data-toggle="tab" aria-controls="home" aria-expanded="true">
							<span class="text">View Doctors</span>
						  </a>
						</li></ul>
						
					  <div id="myTabContent" class="tab-content">
						<div role="tabpanel" class="tab-pane fade in active" id="home" aria-labelledby="home-tab">
						   <div>
												<div id="container">
								
								
								<div class="clearfix"></div>
							<ul class="list">
								<?php
							  $c=mysqli_connect("localhost","root","","doctor");
							if($c==false)
							{
								die ("error in connection");
							}
                              $cat=$_REQUEST["id"];
                              
							$query=mysqli_query($c,"select * from doctorinfo where dept_id= $cat");
						
							$count=mysqli_num_rows($query);
							if($count>=1)
							{
								  
								  while($r=mysqli_fetch_row($query))
								  {
									 
                                     echo"<a href='details.php?id=".$r[0]."'>
									<li>
									<img src='web/images/$r[11]' title='' alt='' 'width='150px' height='150px' />
									<section class='list-left'>
									<h5 class='title'>$r[1]</h5>
									<span class='adprice'>Hospital / Clinic Name :- $r[4]</span>
									<span class='adprice'>Specialization :- ".$r[5]."</span>
									<span class='adprice'>Qualification :- ".$r[13]."</span>
									<p class='catpath'></p>
									</section>
									<section class='list-right'>
									<span class='date'></span>
									<span class='cityname'>Address :- $r[6], $r[7], $r[8], $r[9]</span>
									</section>
									<div class='clearfix'></div>
									</li> 
								</a>";
									 
								  } 
							}
                             else
							 {
								  echo" <div class='alert alert-danger '>
									 
									  <strong>Doctor Are Not Available This Department &nbsp; <a href='index.php' class='alert-link'> GO To Home</a> </strong>
									   </div>";
							 }								 
							
							?>
								
								
								
							</ul>
						</div>
							</div>
						</div>
						<div role="tabpanel" class="tab-pane fade" id="samsa" aria-labelledby="samsa-tab">
						  <div>
												<div id="container">
								<div class="view-controls-list" id="viewcontrols">
									<label>view :</label>
									<a class="gridview"><i class="glyphicon glyphicon-th"></i></a>
									<a class="listview active"><i class="glyphicon glyphicon-th-list"></i></a>
								</div>
								<div class="sort">
								   <div class="sort-by">
										<label>Sort By : </label>
										<select>
														<option value="">Most recent</option>
														<option value="">Price: Rs Low to High</option>
														<option value="">Price: Rs High to Low</option>
										</select>
									   </div>
									 </div>
								<div class="clearfix"></div>
							<ul class="list">
							
								
								
								
							</ul>
						</div>
							</div>
						</div>
						
					  </div>
					</div>
				</div>
				</div>
<?php
 include("footer.php");
?>		
<script type="text/javascript">
	$(document).ready(function()
	{
           var dept = GetParameterValues('id');
        function GetParameterValues(param) {
            var url = window.location.href.slice(window.location.href.indexOf('?') + 1).split('&');
            for (var i = 0; i < url.length; i++) {
                var urlparam = url[i].split('=');
                if (urlparam[0] == param) {
                    return urlparam[1];
                }
            }
        }
        $.ajax({
             type:"POST",
             url:"search.php",
             data:{de:dept},
             success:function(res)
			{
			   $("#Search").val(res);
		    }
        });


        
   
	});
	
</script>
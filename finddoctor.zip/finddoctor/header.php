
<html>
	<head>
		  
				
				<link rel="stylesheet" href="css/bootstrap.min.css"><!-- bootstrap-CSS -->
                <meta name="viewport" content="width=device-width, initial-scale=1">
				<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
				<meta name="keywords" content="" />
				
			<link rel="stylesheet" href="css/bootstrap.min.css"><!-- bootstrap-CSS -->
			<link rel="stylesheet" href="css/bootstrap-select.css"><!-- bootstrap-select-CSS -->
			<!--<link href="css/style.css" rel="stylesheet" type="text/css" media="all" /><!-- style.css -->
			<link href="css/style.css" rel="stylesheet" type="text/css" media="all" /><!-- style.css -->
			<link rel="stylesheet" href="css/font-awesome.min.css" />
			<link href='//fonts.googleapis.com/css?family=Ubuntu+Condensed' rel='stylesheet' type='text/css'>
			<link href='//fonts.googleapis.com/css?family=Open+Sans:400,300,300italic,400italic,600,600italic,700,700italic,800,800italic' rel='stylesheet' type='text/css'>
             <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
             <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
             <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
             <script src="css/jquery.min.js"></script>
       
	</head>
	<body>
	
		<div class="w3ls-header">
			<div class="w3ls-header-left">
				<p><a href="index.php"><i class="fa fa-home" aria-hidden="true"></i> Home </a></p>
			</div>
			<div class="w3ls-header-right">
				<ul>
					<li class="dropdown head-dpdn">
					    
						<a href="signin.php"<i class="fa fa-user"></i> Sign In</a>
					</li>
					<li class="dropdown head-dpdn">
						<a href="#"><i class="fa fa-question-circle"></i> Help</a>
					</li>
					<li class="dropdown head-dpdn">
						<a href="#"><i class="fa fa-user"></i> About Us</span></a>
					</li>
					<li class="dropdown head-dpdn">
						<div class="header-right">			
	                    </div>
					</li>
				</ul>
			</div>
			
			<div class="clearfix"> </div> 
		</div>
		<div class="container">
			<div class="agile-its-header">
				<div class="logo">
					<h1><a href="index.php"><span>Doctor</span> &nbsp;Search</a></h1>
				</div>
				<div class="agileits_search">
					<form action="searchdetail.php" method="post">
					    <input id="agileinfo_search" type="text" name="loca" placeholder=" Location" >
						<input id="Search" type="text" name="det" placeholder="How can we help you today?">
							<button type="submit" name="check" class="btn btn-default" aria-label="Left Align">
							<i class="fa fa-search" aria-hidden="true"> </i>
						</button>
					</form>
				      <a class="post-w3layouts-ad" href="signup.php">Sign up </a>
				</div>	
				
				<div class="clearfix"></div>
			</div>
		</div>
	
			
		</body>
</html>

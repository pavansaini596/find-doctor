
<html>
<head>
	<?php
		include("header.php");
	?>
</head>	
	<body>
	
	  
	
       <div id="agileits-sign-in-page" class="sign-in-wrapper">
			<div class="agileinfo_signin">
			<h3>Super Admin Sign in </h3>
			
				<form  action="" method="post" >
					<label> Email Or Mobile Number *</label>
					<input class="form-control" type="text" name="email" placeholder="Your Email Or Mobile Number" required> 
					<label>Password *</label>
					<input class="form-control" type="password" name="pwd" placeholder="Password" required> 
					<input class="form-control" type="submit" name="dlog" value="Sign In">
				 </form>
				
							<?php
							
							if(isset($_POST["dlog"]))
							{
								      $email=$_POST["email"];
									   $pwd=$_POST["pwd"];
									   $c=mysqli_connect("localhost","root","","doctor");
									    if($c==false)
									    {
										   die("Database connection error");
									   }
									   $query=mysqli_query($c,"select * from supadmin where (email='$email' or BINARY mobile_number= BINARY '$email') and BINARY spassword=BINARY '$pwd'");
									   $count=mysqli_num_rows($query);
									   if($count>=1)
									   {
											$r=mysqli_fetch_row($query);
											session_start();			
											$_SESSION["sdemo"]=$r[0];  
											header("location:web/sindex.php");
									   }
									   else
									   {
										    echo"<div class='alert alert-danger'>
													  <strong> please enter correct detail</strong>
													</div>";
										   
									   }
						   }
				          ?>
						  </div>  
					
				  </div>
				
			 <?php
	    include("footer.php");
	?>
		</body>
</html>


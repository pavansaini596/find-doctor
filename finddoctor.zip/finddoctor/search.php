<?php
  $dept=$_REQUEST["de"];
  
  $c=mysqli_connect("localhost","root","","doctor");
	if($c==false)
	{
		die ("error in connection");
	}
     
	$query=mysqli_query($c,"select * from department where id= $dept");

	$count=mysqli_num_rows($query);
	if($count>=1)
	{
		  
		  $r=mysqli_fetch_row($query);
		  {
		  	 echo $r[1];
		  }
    }


					
?>

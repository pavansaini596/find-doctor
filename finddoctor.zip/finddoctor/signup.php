<?php
ob_start();
?>
<html>
	<head>
		  <title>Doctor and Patient  Signup</title>	
    		  <link rel="stylesheet" href="css/bootstrap.min.css"><!-- bootstrap-CSS -->
            <meta name="viewport" content="width=device-width, initial-scale=1">
			<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
			<meta name="keywords" content="" />
			<link rel="stylesheet" href="css/bootstrap-select.css"><!-- bootstrap-select-CSS -->
			<link href="css/style.css" rel="stylesheet" type="text/css" media="all" /><!-- style.css -->
			<link rel="stylesheet" href="css/font-awesome.min.css" />
			<link href='//fonts.googleapis.com/css?family=Ubuntu+Condensed' rel='stylesheet' type='text/css'>
			<link href='//fonts.googleapis.com/css?family=Open+Sans:400,300,300italic,400italic,600,600italic,700,700italic,800,800italic' rel='stylesheet' type='text/css'>
              <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
             <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
             <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
 <?php
		include("header.php");
	?>
	</head>
	<body>
	 
       <div id="agileits-sign-in-page" class="sign-in-wrapper">
			<div class="agileinfo_signin">
			<h3>Sign Up</h3>
				<ul class="nav nav-tabs">
				   <li class="col-sm-6 nav-item"><a class="nav-link" data-toggle="tab" href="#regdoc">Register As Doctor</a></li>
				   <li class="col-sm-6 nav-item"><a class="nav-link" data-toggle="tab" href="#regpes">Register As Patient</a></li>
                </ul>
					  <div class="tab-content">
					  <div id="regdoc" class="tab-pane fade "><br>
					         <h3>Register As Doctor</h3>
								<form  action="" method="post" >
									<label> Name *</label>
									<input class="form-control" type="text" name="name"  placeholder="Your Name" required>
									<label> Email *</label>
									<input class="form-control" type="email" name="email" placeholder="Your Email" required>
									<label> Mobile Number *</label>
									<input class="form-control" type="tel" name="mob" placeholder="Mobile Number" pattern="[0-9]{10}" maxlength="10" minlength="10" size="10" required>
									<label>Password *</label>
									<input class="form-control" type="password" name="pwd" placeholder="Password" required="">
									<div class="signin-rit">
										<span class="agree-checkbox">
											<label class="checkbox"><input type="checkbox" name="checkbox" required> &nbsp;&nbsp;I agree to your <a class="w3layouts-t" href="#" target="">Terms of Use</a> and <a class="w3layouts-t" href="#" target="">Privacy Policy</a></label><br>
										</span>
									</div>
									<input class="form-control" type="submit" name="dsubmit" value="Sign Up">
								</form>
						</div>
						
					     <?php
                           if(isset($_POST["dsubmit"]))
								    {
									    $name=$_POST["name"];
									    $email=$_POST["email"];
									    $mob=$_POST["mob"];
									    $pwd=$_POST["pwd"];
									    
									  
									    $c=mysqli_connect("localhost","root","","doctor");
									    if($c==false)
									    {
										   die("Database connection error");
									   }
									   $query=mysqli_query($c,"select * from doctorinfo where email='$email' or mobile_number='$mob'");
									   $count=mysqli_num_rows($query);
									   if($count>=1)
									   {
										   echo"<br><div class='alert alert-danger'>
													  <strong> your email or moblie number alredy exist.</strong>
													</div>";
									   } 
									   else
									   {
										 if(mysqli_query($c,"insert into doctorinfo (name,email,mobile_number,dpassword,ac_status) values('$name','$email','$mob','$pwd','Active')"))
										  {      	
											 $query=mysqli_query($c,"select * from doctorinfo where email='$email' or mobile_number='$mob'");
									         $count=mysqli_num_rows($query);
											 if($count>=1)
											 {												
									              $r=mysqli_fetch_row($query);
												   session_start();		
   												    $_SESSION["demo"]=$r[0];
												  	header("location:web/dindex.php");
											  }    
										   }
										   else
										   {
											    echo"<br><div class='alert alert-danger'>
													  <strong> your account not create please retry.</strong>
													</div>";
											 
										   }
									   }
								   }
						   ?> 
						   
						   <div id="regpes" class="tab-pane fade"><br>
						        <h3>Register As Patient</h3>
										<form action="" method="post">
											<label> Name *</label>
											<input class="form-control" type="text" name="name" placeholder="Your Name" required> 
											<label> Email</label>
											<input class="form-control" type="email" name="email" placeholder="Your Email">
											<label> Mobile Number *</label>
											<input class="form-control" type="tel" name="mob" placeholder="Mobile Number" pattern="[0-9]{10}" maxlength="10" minlength="10" size="10" required>
											<label> Password *</label>							   
											<input class="form-control" type="password" name="pwd" placeholder="Password" required=""> 
											
											<div class="signin-rit">
												<span class="agree-checkbox">
													<label class="checkbox"><input type="checkbox" name="checkbox" required> &nbsp;&nbsp;I agree to your <a class="w3layouts-t" href="terms.html" target="_blank">Terms of Use</a> and <a class="w3layouts-t" href="privacy.html" target="_blank">Privacy Policy</a> </label><br>
												</span>
											</div>
											<input class="form-control" type="submit"  name="usubmit" value="Sign Up">
										</form>
								 </div>
								 
								  <?php
						            
						           if(isset($_POST["usubmit"]))
								   {
									   $name=$_POST["name"];
									   $email=$_POST["email"];
									   $mob=$_POST["mob"];
									   $pwd=$_POST["pwd"];
									  
									  
									   $c=mysqli_connect("localhost","root","","doctor");
									   if($c==false)
									   {
										   die("Database connection error");
									   }
									   $query=mysqli_query($c,"select * from userinfo where email='$email' or mobile_number='$mob'");
									   $count=mysqli_num_rows($query);
									   if($count>=1)
									   {
										   echo"<br><div class='alert alert-danger'>
													  <strong> your email or moblie number alredy exist.</strong>
													</div>";
									   } 
									   else
									   {
										 if(mysqli_query($c,"insert into userinfo (name,email,mobile_number,upassword,acc_status) values('$name','$email','$mob','$pwd','Active')"))
										  {  
									             	
											 $query=mysqli_query($c,"select * from userinfo where email='$email' or mobile_number='$mob'");
									         $count=mysqli_num_rows($query);
											 if($count>=1)
											 {												
									              $r=mysqli_fetch_row($query);
												   session_start();		
   												    $_SESSION["udemo"]=$r[0];
												 	header("location:web/uindex.php");
											 }    
										  }
										  else
										  {
											 echo"<br><div class='alert alert-danger'>
													  <strong> your account not create please retry.</strong>
													</div>";
										  }
									  }
								   }
						         ?>
			   </div>
		</div>
	</div>
     <?php
	    include("footer.php");
	?>
   </body>
</html>
<?php
ob_end_flush();
?>
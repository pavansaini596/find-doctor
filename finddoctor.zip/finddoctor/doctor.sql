-- phpMyAdmin SQL Dump
-- version 4.8.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Feb 25, 2020 at 03:31 PM
-- Server version: 10.1.36-MariaDB
-- PHP Version: 5.6.38

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `doctor`
--

-- --------------------------------------------------------

--
-- Table structure for table `appointment`
--

CREATE TABLE `appointment` (
  `id` int(11) NOT NULL,
  `patient_id` int(35) DEFAULT NULL,
  `doctor_id` int(35) DEFAULT NULL,
  `hospital_name` varchar(100) DEFAULT NULL,
  `app_time` varchar(40) DEFAULT NULL,
  `day` varchar(25) DEFAULT NULL,
  `date` varchar(25) DEFAULT NULL,
  `fee` varchar(20) DEFAULT NULL,
  `app_status` varchar(45) DEFAULT NULL,
  `p_name` varchar(25) DEFAULT NULL,
  `f_h_name` varchar(65) DEFAULT NULL,
  `patient_age` int(5) DEFAULT NULL,
  `description` varchar(1000) DEFAULT NULL,
  `doc_name` varchar(65) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `appointment`
--

INSERT INTO `appointment` (`id`, `patient_id`, `doctor_id`, `hospital_name`, `app_time`, `day`, `date`, `fee`, `app_status`, `p_name`, `f_h_name`, `patient_age`, `description`, `doc_name`) VALUES
(1, 1, 7, 'happy clinic', '11:00 AM', 'sunday', '2019-12-08', '350', 'Complete', 'ravi', 'ravindra', 18, '									  									  \r\ncough syrup 1 table spoon\r\n									\r\n									', 'doctor7'),
(2, 1, 1, 'D Clinic', '5:00 PM', 'MONDAY', '2019-12-09', '300', 'Pending', 'surendra', 'ramesh', 25, NULL, 'doctor'),
(3, 1, 7, 'happy clinic', '11:00 AM', 'FRIDAY', '2019-12-06', '350', 'Pending', 'surendra', 'SURESH', 23, NULL, 'doctor7'),
(4, 1, 7, 'happy clinic', '1:00 PM', 'THURSDAY', '2019-12-19', '350', 'Pending', 'MOHAN', 'RAJESH', 10, NULL, 'doctor7'),
(5, 1, 7, 'happy clinic', '2:00 PM', 'Staurday', '2019-12-21', '350', 'Cancel', 'SUYESH', 'RINKU', 12, NULL, 'doctor7'),
(6, 7, 1, 'sms', '1:00 PM', 'MONDAY', '2019-12-16', '10', 'Complete', 'rajesh', 'abc', 34, '									  kfojdnjij gfioghn  \r\n									', 'doctor');

-- --------------------------------------------------------

--
-- Table structure for table `department`
--

CREATE TABLE `department` (
  `id` int(11) NOT NULL,
  `department_name` char(30) DEFAULT NULL,
  `department_img` varchar(25) DEFAULT NULL,
  `d_status` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `department`
--

INSERT INTO `department` (`id`, `department_name`, `department_img`, `d_status`) VALUES
(1, 'cardiologist', 'cardiologist.jpg', 'Active'),
(2, 'dentist', 'dentist.jpg', 'Active'),
(3, 'dermatologist', 'dermatologist.jpg', 'Active'),
(4, 'ENT', 'ent.jpg', 'Active'),
(5, 'oncologist', 'oncologist.jpg', 'Active'),
(6, 'ophthalmologist', 'ophthalmologist.jpg', 'Active'),
(7, 'pediatrician', 'pediatrician.jpg', 'Active'),
(8, 'psychologist', 'psychologist.jpg', 'Active');

-- --------------------------------------------------------

--
-- Table structure for table `doctorinfo`
--

CREATE TABLE `doctorinfo` (
  `id` int(11) NOT NULL,
  `name` char(25) DEFAULT NULL,
  `email` varchar(30) DEFAULT NULL,
  `mobile_number` varchar(15) DEFAULT NULL,
  `h_c_name` varchar(65) DEFAULT NULL,
  `specialization` char(60) DEFAULT NULL,
  `address` varchar(70) DEFAULT NULL,
  `landmark` varchar(20) DEFAULT NULL,
  `c_v_name` char(45) DEFAULT NULL,
  `state_name` char(40) DEFAULT NULL,
  `dpassword` varchar(35) DEFAULT NULL,
  `dphoto` varchar(75) DEFAULT NULL,
  `dept_id` int(15) DEFAULT NULL,
  `qualification` varchar(100) DEFAULT NULL,
  `ac_status` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `doctorinfo`
--

INSERT INTO `doctorinfo` (`id`, `name`, `email`, `mobile_number`, `h_c_name`, `specialization`, `address`, `landmark`, `c_v_name`, `state_name`, `dpassword`, `dphoto`, `dept_id`, `qualification`, `ac_status`) VALUES
(1, 'doctor', 'doctor@gmail.com', '1234567890', 'D clinic', 'cardiologist', 'jaipur', 'near junction', 'jaipur', 'rajasthan', 'doctor@123', 'download1.jpg', 1, 'mbbs', 'Active'),
(2, 'doctor2', 'doctor2@gmail.com', '9352735846', 'Dk clinic', 'cardiologist', 'alwar', 'shivaji park', 'alwar', 'rajasthan', 'doctor2@123', 'download2.jpg', 1, 'mbbs', 'Active'),
(3, 'doctor3', 'doctor3@gmail.com', '9660574845', 'life clinic', 'ENT', 'jaipur', 'mansarovar 233 ', 'jaipur', 'rajasthan', 'docto3@123', 'download3.jpg', 4, 'mbbs', 'Active'),
(4, 'doctor4', 'doctor4@gmail.com', '8465528225', 'sk clinic', 'ENT', 'delhi', 'old delhi junction', 'delhi', 'delhi', 'doctor4@123', 'download4.jpg', 4, 'mbbs, md', 'Active'),
(5, 'doctor5', 'doctor5@gmail.com', '7821211211', 'hk clinic', 'ENT', 'delhi', 'new delhi junction', 'delhi', 'delhi', 'doctor5@123', 'download5.jpg', 4, 'mbbs, md', 'Active'),
(6, 'doctor6', 'doctor6@gmail.com', '6814574512', 'rajat clinic', 'dermatologist', 'baswa', 'railaway station', 'baswa', 'rajasthan', 'doctor@123', 'download6.jpg', 3, 'mbbs', 'Active'),
(7, 'doctor7', 'doctor7@gmail.com', '8756825125', 'happy clinic', 'pediatrician', 'udaipur', 'railwary station', 'udaipur', 'rajasthan', 'doctor7@123', 'download7.jpg', 7, 'mbbs', 'Active'),
(8, 'doctor8', 'doctor8@gmail.com', '8825746454', 'kamal clinic', 'psychologist', 'baswa', 'near railway station', 'baswa', 'rajasthan', 'doctor8@123', 'download8.jpg', 8, 'mbbs', 'Active'),
(9, 'doctor9', 'doctor9@gmail.com', '6367852555', 'verma clinic', 'oncologist', 'bikaner', 'world park', 'bikaner', 'rajasthan', 'doctor9@123', 'oncologist.jpg', 5, 'mbbs', 'Active');

-- --------------------------------------------------------

--
-- Table structure for table `experience`
--

CREATE TABLE `experience` (
  `id` int(11) NOT NULL,
  `doctor_id` int(25) DEFAULT NULL,
  `hospital_name` varchar(45) DEFAULT NULL,
  `experience` varchar(5) DEFAULT NULL,
  `frome_date` varchar(10) DEFAULT NULL,
  `to_date` varchar(10) DEFAULT NULL,
  `detail` varchar(45) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `experience`
--

INSERT INTO `experience` (`id`, `doctor_id`, `hospital_name`, `experience`, `frome_date`, `to_date`, `detail`) VALUES
(1, 1, 'sms', '2', '2008-02-20', '2010-02-21', 'cardiologist'),
(2, 1, 'govt hospital', '4', '2010-02-22', '2014-02-22', 'sr. cardiologist'),
(3, 1, 'sms', '5', '2014-02-23', '2019-02-23', 'sr. cardiologist'),
(4, 2, 'govt hospital alwar', '2', '2017-12-02', '2019-12-01', 'sr. cardiologist'),
(5, 3, 'life clinic', '2', '2017-11-30', '2019-12-01', 'ENT'),
(6, 4, 'sms', '2', '2017-07-05', '2019-10-08', 'ENT'),
(7, 5, 'govt hospital', '5', '2014-02-15', '2019-11-30', 'ent'),
(8, 6, 'rajat clinic', '3', '2017-05-04', '2019-02-24', 'dermatologist'),
(9, 7, 'happy clinic', '2', '2013-05-02', '2015-02-05', 'pediatrician'),
(10, 8, 'kamal clinic', '4', '2013-02-04', '2017-05-04', 'psychologist'),
(11, 9, 'verma clinic', '5', '2013-08-05', '2017-11-08', 'oncologist');

-- --------------------------------------------------------

--
-- Table structure for table `metting`
--

CREATE TABLE `metting` (
  `id` int(11) NOT NULL,
  `doctor_id` int(10) DEFAULT NULL,
  `hospital_name` varchar(50) DEFAULT NULL,
  `m_time` varchar(20) DEFAULT NULL,
  `day` varchar(100) DEFAULT NULL,
  `fee` int(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `metting`
--

INSERT INTO `metting` (`id`, `doctor_id`, `hospital_name`, `m_time`, `day`, `fee`) VALUES
(1, 1, 'sms', '11:00 AM to 3:00 PM', 'Monday, Tuesday, Wednesday  ', 10),
(2, 1, 'D Clinic', '4:00 PM to 7:00 PM', 'All Day', 300),
(3, 1, 'D Clinic', '11:00 AM to 3:00 PM', 'Thursday, Friday, Saturday Sunday', 300),
(4, 2, 'govt hospital alwar', '11:00 AM to 3:00 PM', 'Monday, Tuesday, friday', 10),
(5, 2, 'Dk Clinic', '4:00 PM to 7:00 PM', 'Monday, Tuesday, friday', 200),
(6, 2, 'Dk Clinic', '10:00 AM to 4:00 PM', ' Wednesday  , Thursday', 200),
(7, 3, 'life clinic', '11:00 AM to 3:00 PM', 'All Day', 300),
(8, 3, 'life clinic', '4:00 PM to 7:00 PM', 'Saturday, Sunday', 300),
(9, 4, 'sms', '11:00 AM to 3:00 PM', 'All Day', 10),
(10, 4, 'sk clinic', '4:00 PM to 7:00 PM', 'All Day', 300),
(11, 5, 'govt hospital', '10:00 AM to 3:00 PM', 'All Day', 10),
(12, 5, 'hk clinic', '4:00 PM to 7:00 PM', 'Thursday, Friday, Saturday Sunday', 350),
(13, 6, 'rajat clinic', '4:00 PM to 7:00 PM', ' Wednesday  , Thursday', 200),
(14, 6, 'rajat clinic', '10:00 AM to 4:00 PM', 'Saturday, Sunday', 200),
(15, 7, 'happy clinic', '10:00 AM to 3:00 PM', 'Thursday, Friday, Saturday Sunday', 350),
(16, 8, 'kamal clinic', '11:00 AM to 3:00 PM', 'Thursday, Friday, Saturday Sunday', 450),
(17, 9, 'verma clinic', '10:00 AM to 4:00 PM', ' Wednesday  , Thursday', 350);

-- --------------------------------------------------------

--
-- Table structure for table `supadmin`
--

CREATE TABLE `supadmin` (
  `id` int(11) NOT NULL,
  `name` char(20) DEFAULT NULL,
  `email` varchar(35) DEFAULT NULL,
  `mobile_number` varchar(15) DEFAULT NULL,
  `spassword` varchar(40) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `supadmin`
--

INSERT INTO `supadmin` (`id`, `name`, `email`, `mobile_number`, `spassword`) VALUES
(1, 'super admin', 'superadmin@gmail.com', '1234567890', 'superadmin@123');

-- --------------------------------------------------------

--
-- Table structure for table `userinfo`
--

CREATE TABLE `userinfo` (
  `id` int(11) NOT NULL,
  `name` char(25) DEFAULT NULL,
  `email` varchar(45) DEFAULT NULL,
  `mobile_number` varchar(15) DEFAULT NULL,
  `upassword` varchar(25) DEFAULT NULL,
  `acc_status` varchar(15) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `userinfo`
--

INSERT INTO `userinfo` (`id`, `name`, `email`, `mobile_number`, `upassword`, `acc_status`) VALUES
(1, 'patient', 'patient@gmail.com', '1234567890', 'patient@123', 'Active'),
(3, 'patient2', 'patient2@gmail.com', '1236547890', 'patient2@123', 'Active'),
(4, 'patient3', 'patient3@gmail.com', '1023456789', 'patient3@123', 'Active'),
(5, 'patient4', 'patient4@gmail.com', '9654123870', 'patient4@123', 'Active'),
(6, 'patient5', 'patient5@gmail.com', '9685231475', 'patient5@123', 'Active'),
(7, 'patient6', 'patient6@gmail.com', '9874521305', 'patient6@123', 'Active');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `appointment`
--
ALTER TABLE `appointment`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `department`
--
ALTER TABLE `department`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `doctorinfo`
--
ALTER TABLE `doctorinfo`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `experience`
--
ALTER TABLE `experience`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `metting`
--
ALTER TABLE `metting`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `supadmin`
--
ALTER TABLE `supadmin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `userinfo`
--
ALTER TABLE `userinfo`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `appointment`
--
ALTER TABLE `appointment`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `department`
--
ALTER TABLE `department`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `doctorinfo`
--
ALTER TABLE `doctorinfo`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `experience`
--
ALTER TABLE `experience`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `metting`
--
ALTER TABLE `metting`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT for table `supadmin`
--
ALTER TABLE `supadmin`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `userinfo`
--
ALTER TABLE `userinfo`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
